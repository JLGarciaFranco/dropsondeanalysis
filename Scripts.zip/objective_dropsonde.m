% objective_dropsonde.m
% Tracks of Danielle from various data for objective track paper.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Flightlevel data - based on analyse_flightlevel.m %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if isunix
    addpath('~hurricanes/tc_cases/matlab');
else
    addpath('c:/Dokumente und Einstellungen/Hurricanes/matlab');
    addpath('c:/Dokumente und Einstellungen/Hurricanes/tc_cases/matlab');
end

format short g
clear
clear global

flights = {
 '19980830HI' ;
 '19980829HI' 
};

nfl = length(flights);

% for ifl = 1 : nfl
% for ifl = 1
ifl = 1;

   flight = flights{ifl};
   
   load('matlab/Danielle98_nhctrack');
   
   relwind = 0;  % Iterations for rel winds for wind-based techniques
   
   load('matlab/Danielle98_nhctrack.mat');
   % Base positions come from the NHC best-track interpolated to time0
   switch flight

      case {'19980830HI'}
         load('matlab/Danielle_19980830HI_dropsonde_04_frd.mat');
         rmplot = 150; zrplot = 100; vmplot = 30;
         rsel1 =  0e3; rsel2 = 150e3;  % Big storm!
         a0h = [ 25; 40e3; 0.8; nan; nan ];
      case {'19980829HI'}
         load('matlab/Danielle_19980829HI_dropsonde_04_frd.mat');
         rmplot = 150; zrplot = 100; vmplot = 30;
         rsel1 =  0e3; rsel2 = 150e3;  % Big storm!
         a0h = [ 25; 40e3; 0.8; nan; nan ];
      otherwise
         disp(sprintf('Unrecognised flight %s', flight));
     %   break;
   end
   nhc_x = (nhc_lon - tclon0)*pi/180*6370e3 .* cos(nhc_lat*pi/180);
   nhc_y = (nhc_lat - tclat0)*pi/180*6370e3;

   zxrel = zx - interp1(nhc_time, nhc_x, ztime);
   zyrel = zy - interp1(nhc_time, nhc_y, ztime);
   zrrel = sqrt( zxrel.^2 + zyrel.^2 );
   zspd = sqrt( zuex.^2 + zvex.^2 );

   [zuec,zvec] = cart2cyl(zuex,zvex,zxrel,zyrel); 

   savename = sprintf('matlab/results_dropsonde_%s', flight);
   tclat0 = interp1(nhc_time, nhc_lat, time0); tclon0 = interp1(nhc_time, nhc_lon, time0);
   ut = interp1(nhc_time, nhc_ut, time0); vt = interp1(nhc_time, nhc_vt, time0);
   rfit = max(rsel1,1e3) : 1e3 : (rmplot*1e3);
   a0s = [ 0; 0; ut; vt ]; a0h = [ a0h ; a0s ];
   
   
   % Willoughby-Chelmow track

   lev = 101;   
 
   use = find( ~isnan(zuex(lev,:)) & ~isnan(zx(lev,:)) & rsel1 <= zrrel(lev,:) & zrrel(lev,:) < rsel2); 
              
   xobs = zx(lev,use); yobs = zy(lev,use); 
   tobs = (ztime(lev,use) - time0)*86400;
   uobs = zuex(lev,use); vobs = zvex(lev,use);
   sigv = 1.0;
   sigdir = min( sigv./hypot(uobs,vobs), pi/2 );
   [awc, errwc] = wi_ch_asyn(xobs,yobs,tobs,uobs,vobs,'auto',sigdir,relwind);
   % Transform into WC coordinates
   xwc = zx(lev,use) - awc(1) - (ztime(lev,use) - time0)*86400*awc(3);
   ywc = zy(lev,use) - awc(2) - (ztime(lev,use) - time0)*86400*awc(4);
   rwc = hypot(xwc,ywc);
   uxrwc = zuex(lev,use) - awc(3); vxrwc = zvex(lev,use) - awc(4);
   ucrwc = ( xwc.*uxrwc + ywc.*vxrwc ) ./ rwc;
   vcrwc = (-ywc.*uxrwc + xwc.*vxrwc ) ./ rwc;
   inrwc = atan2(ucrwc,vcrwc)*180/pi;
   
   
     
   % Simplex track
   use = find( ~isnan(zuex(lev,:)) & ~isnan(zx(lev,:)) & rsel1 < zrrel(lev,:)  < rsel2  );
   uv = [zuex(lev,use)',zvex(lev,use)'];
   xyt = [zx(lev,use)',zy(lev,use)',86400*(ztime(lev,use)' - time0)];
   [a,circ] = simplex_track(uv, xyt, a0s, relwind);
   % [aaa,circ] = simplex_track(uv, xyt, a, 1);
   if any(abs(a) > 1e6)
      a = a + nan;
      disp('**** Simplex fit failed');
   else
      % Transform into simplex-track coordinates
      xs = zx(lev,use) - a(1) - (ztime(lev,use) - time0)*86400*a(3);
      ys = zy(lev,use) - a(2) - (ztime(lev,use) - time0)*86400*a(4);
      rs = hypot(xs,ys);
      uxrs = zuex(lev,use) - a(3); vxrs = zvex(lev,use) - a(4);
      ucrs = ( xs.*uxrs + ys.*vxrs ) ./ rs;
      vcrs = (-ys.*uxrs + xs.*vxrs ) ./ rs;
      inrs = atan2(ucrs,vcrs)*180/pi;
             
  end
   
   % Fit Holland pressure profile and track-find.
   global f0
   f0 = cor(tclat0);
   use = find(~isnan(zp(lev,:)) & rsel1 <= zrrel(lev,:) & zrrel(lev,:) < rsel2);
   xobs = zx(lev,use); yobs =zy(lev,use); robs = hypot(xobs,yobs);
   tobs = (ztime(lev,use) - time0)*86400;
   pobs = zp(lev,use);
   Tbar = nanmean(zT(lev,use));
   xyt = [ xobs', yobs', tobs' ];
   sigp = 1000*ones(size(xobs));
   
   lev = 1;   

   a0h(4) = min(pobs); a0h(5) = Tbar;
   ia = [ 1 1 1 1 0 1 1 1 1 ]';  % Don't fit environmental temperature
   [ah,cov,chisq] = mrqmin_multi(xyt, pobs, sigp, a0h, ia, @holland_p_xyuv, 50, 10);
   
   xh = zx(lev,:) - ah(6) - (ztime(lev,:) - time0)*86400*ah(8);
   yh = zy(lev,:) - ah(7) - (ztime(lev,:) - time0)*86400*ah(9);
   rh = hypot(xh,yh); lh = mod(atan2(yh,xh)*180/pi,360);
   uxrh = zuex(lev,:) - ah(8); vxrh = zvex(lev,:) - ah(9);
   ucrh = ( xh.*uxrh + yh.*vxrh ) ./ rh;
   vcrh = (-yh.*uxrh + xh.*vxrh ) ./ rh;
   inrh = atan2(ucrh,vcrh)*180/pi;
   zh = holland_z(rh,ah(1:5));
   zfh = holland_z(rfit,ah(1:5));
   vfh = holland_vz(rfit,ah(1:5));
  

      
   % Compare tracks to low-res HRD, high-res HRD, and NHC

 % load('matlab/danielle98_hrdtrack');
 % load('matlab/danielle98_ctr');
 % hrd_x = (hrd_lon - tclon0)*6370e3*pi/180 * cos(tclat0*pi/180);
 % hrd_y = (hrd_lat - tclat0)*6370e3*pi/180;
 % hrd2_x = (tc_lon(timeok) - tclon0)*6370e3*pi/180 * cos(tclat0*pi/180);
 % hrd2_y = (tc_lat(timeok) - tclat0)*6370e3*pi/180;
 % ctrok = find( min(time(timeok)) <= ctr_time & ctr_time <= max(time(timeok)) );
 % ctr_x = (ctr_lon(ctrok) - tclon0)*6370e3*pi/180 * cos(tclat0*pi/180);
 % ctr_y = (ctr_lat(ctrok) - tclat0)*6370e3*pi/180;
   nhc_x = (nhc_lon - tclon0)*6370e3*pi/180 * cos(tclat0*pi/180);
   nhc_y = (nhc_lat - tclat0)*6370e3*pi/180;
   trange = [min(ztime(lev,use)) ; max(ztime(lev,use))] - time0;
   sim_x = a(1) + trange*86400*a(3);
   sim_y = a(2) + trange*86400*a(4);
   hol_x = ah(6) + trange*86400*ah(8);
   hol_y = ah(7) + trange*86400*ah(9);
   wc_x = awc(1) + trange*86400*awc(3);
   wc_y = awc(2) + trange*86400*awc(4);
   
   fig(7); clf;
   hold on; xylim(2e5); set(gca,'DataAspectRatio',[1 1 1]);
 % plot(hrd_x,hrd_y,'r-'); 
 % plot(interp1(hrd_time,hrd_x,time0+[-2:2]/8),interp1(hrd_time,hrd_y,time0+[-2:2]/8),'ro');
 % plot(hrd2_x,hrd2_y,'k-');
   plot(nhc_x,nhc_y,'b-');
 % plot(ctr_x,ctr_y,'c-o');
   plot(interp1(nhc_time,nhc_x,time0+[-2:2]/8),interp1(nhc_time,nhc_y,time0+[-2:2]/8),'bo');
   plot(sim_x,sim_y,'g-');
   plot(a(1) + [-3 0 3]*3600*a(3), a(2) + [-3 0 3]*3600*a(4), 'go');
   plot(hol_x,hol_y,'m-');
   plot(ah(6) + [-3 0 3]*3600*ah(8), ah(7) + [-3 0 3]*3600*ah(9), 'mo');
   plot(wc_x,wc_y,'g-');
   plot(awc(1) + [-3 0 3]*3600*awc(3), awc(2) + [-3 0 3]*3600*awc(4), 'g+');
   hline(0); vline(0);
   title(sprintf('Various tracks: %s %s %d hPa',hurr,flight, flev));
   
   save(savename, 'a', 'a0h', 'a0s', 'ah', 'awc', 'errwc', ...
        'flight');

   fig(8); clf;
   subplot(2,1,1); cla reset;
   plot(hobs(timeok),z_pnom(timeok)); ylabel('z_{pnom}'); hline(ah(4),':');
   title(sprintf('%s Base time %s',flight,datestr(time0)));
   subplot(2,1,2); cla reset;
   plot(hobs(timeok),hypot(uxe(timeok),vxe(timeok))); ylabel('Wind speed'); hline(ah(1),':');
   xlabel('Hours from base');

   disp(sprintf('WC  %.2f %.2f %.2f %.2f', ...
        mean(rmwc)/1e3, 2*std(rmwc)/1e3,mean(vmwc),2*std(vmwc)));
   disp(sprintf('MHG %.2f %.2f %.2f %.2f', ...
        mean(rms)/1e3, 2*std(rms)/1e3,mean(vms),2*std(vms)));
   disp(sprintf('TPF %.2f %.2f %.2f %.2f', ...
        mean(rmh)/1e3, 2*std(rmh)/1e3,mean(vmh),2*std(vmh)));

   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   %% Radial temperature gradient %%
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   if 0
      rsel1 = 0; rsel2 = 200e3; 
      rrfit = [max(1e3,rsel1) : 1e3 : rsel2]';

      use = find( ~isnan(zT) & rsel1 <= rh & rh < rsel2 );
      xobs = xh(lev,use); yobs = yh(lev,use); robs = hypot(xobs,yobs);
      tobs = (ztime(lev,use) - time0)*86400;
      zobs = zp(lev,use); 
      Tobs = zT(lev,use) + (zobs - zobs(1))*0.01;
      Tobs = zT(lev,use);
      nobs = length(lev,use);

      sigT = ones(size(robs));
      a0 = [ 25, 50e3, 1.8, 16 ]';
      ia = ones(4,1);
      [aT,cov,chisq] = mrqmin(robs, Tobs, sigT, a0, ia, @holland_T, 30, 10);

      Tafit = holland_T(rrfit,aT);

      fig(9); clf;
      if 0
      subplot(2,1,1); cla reset;
      plot(robs,Tobs,'b.'); hold on;
      plot(rrfit,Tafit,'r-','LineWidth',2);
      xlim(0,rsel2);
      xlabel('Radius (km)'); ylabel('T_a (K)');
      title(sprintf('%s %s a_t=[%.1f %.1f %.1f %.1f]',hurr,flight,aT./[1;1e3;1;1]));
      end

      rsel2 = 100e3;
      use = find(timeok & ~isnan(Ta) & rsel1 <= rh & rh < rsel2 );
      use = use(1 : 5 : length(lev,use)); nobs = length(lev,use);
      xobs = xh(use); yobs = yh(use); robs = hypot(xobs,yobs);
      tobs = (ztime(lev,use) - time0)*86400;
      zobs = zp(lev,use); 
      Tobs = zT(lev,use) + (zobs - zobs(1))*0.01;
      Tobs = zT(lev,use);
      Tbar = nanmean(Tobs) + 273.15;

      ds = 10e3;
      [xg,yg] = meshgrid( -rsel2-ds:ds:rsel2+ds, -rsel2-ds:ds:rsel2+ds ); rg = hypot(xg,yg);

      sigbT = 2;          % Background errors for swf
      sigoT = 1;          % Observation error for swf
      Lrad = 30e3;          % Radial length scales (m)
      Laz  = pi/3;          % Azimuthal length scales (radians)
      Tb = reshape(holland_T(rg, aT), size(xg));

      [Tanal Terr1] = tcsi(xg,yg,Tb,xobs,yobs,Tobs,Lrad,Laz,sigbT,sigoT);

   %  subplot(2,1,2); cla reset;
      contourf(xg/1e3,yg/1e3,Tanal,floor(min(Tobs)):ceil(max(Tobs)),'k'); hold on; colorbar('vert');
      set(gca,'DataAspectRatio',[1 1 1]);
      h = text(xobs(1:5:nobs)/1e3,yobs(1:5:nobs)/1e3,num2str(Tobs(1:5:nobs),'%.1f'));
      set(h, 'HorizontalAlignment','center','VerticalAlignment','middle','Color',[0 0 0]);
      set(h,'FontSize',8);
      plot(-ah(6)/1e3,-ah(7)/1e3,'w+','MarkerSize',20,'LineWidth',3);
      title(sprintf('%s %s a_t=[%.1f %.1f %.1f %.1f]',hurr,flight,Ta./[1;1e3;1;1]));
      xlabel('x (km)'); ylabel('y (km)');
      hline(0); vline(0);
   end

   if 0 
    % cprint([5 7]); 
      bwprint(8); 
   end;

   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   %% Fit Willoughby parametric wind profiles  %%
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   na = 9;
   ia  = [ 1 1 1 0 1 1 0 0 0 ]';
   L2 = 500e3; Lb = 10e3;
   rrfit = [0 : 1e3 : 150e3];

   global w2v_rmhat w2v_rmscal w2v_L1hat w2v_L1scal w2v_L2hat w2v_L2scal

   w2v_rmhat = 25e3; w2v_rmscal = 1;
   w2v_L1hat = 3e4;  w2v_L1scal = 1;
   w2v_L2hat =  L2;  w2v_L2scal = 0;
 
   rsel2w = 500e3;
   use = find(rsel1 < rh & rh < rsel2w & ~isnan(vcrh) );
 % use = find(~isnan(vcrh) );
   xobs = xh(use)'; yobs = yh(use)'; robs = rh(use)'; lobs = lh(use)';
   zobs = zbar(lev)';
   pobs = zp(lev,use)';
   Tobs = zT(lev,use)';
   pmin = mean(pobs(find(robs < 10e3)));
   if isnan(pmin)
      pmin = mean(pobs(find(robs < 10e3)));
   end
   uobs = ucrh(use)'; vobs = vcrh(use)';
   hobs = (ztime(lev,use)' - time0)*24;
   rhoobs = pobs./(287*Tobs); 
   nobs = length(use);
   sigv = 5*ones(nobs,1);
   sigr = 1e3*ones(nobs,1);

   r1 = [robs' ]; v1 = [vobs']; sig1 = [sigv];
   a0 = [ 15, 30e3, 15, L2, 25e3, 1.5, pmin, nanmean(Tobs) Lb ]';
   [awv,cov,chisqwv] = mrqmin(r1, v1, sig1, a0, ia, @willoughby2_v, 100, 10);
   nf = nobs - sum(ia);

   pgfit = willoughby2_p_numerical(rrfit,awv);
   vvfit = willoughby2_v(rrfit,awv);
   pres = pobs - willoughby2_p_numerical(robs,awv);
   vres = vobs - willoughby2_v(robs,awv);

   clear global w2v_rmhat w2v_rmscal w2v_L1hat w2v_L1scal w2v_L2hat w2v_L2scal

   save(savename);
   % load(savename);

   ix1 = find(15e3 < robs & robs < 40e3); ix2 = find(50e3 < robs & robs < 100e3);
   fig(10); clf;
   subplot(4,2,1); cla reset;
   plot(robs*1e-3,pobs*1e-2,'bo','MarkerSize',4); hold on;
   plot(rrfit*1e-3,pgfit*1e-2,'r-','LineWidth',2);
   xlim(0,rsel2*1e-3); yrange(80,0,0);
   title(sprintf('z=%.0f, \\chi^2/n_f=%.3f, %s %s',zbar(lev),chisq/nf,hurr,flight));
   ylabel('pressure');
   subplot(4,2,2); cla reset;
   plot(robs*1e-3,vobs,'bo','MarkerSize',4); hold on;
   plot(rrfit*1e-3,vvfit,'r-','LineWidth',2);
   xlim(0,rsel2*1e-3); yrange(80,0,0);
   title(sprintf('a=[%.1f %.1f %.1f %.1f %.1f %.2f %.1f]',awv(1:7)./[1 1e3 1 1e3 1e3 1 1e2]'));
   ylabel('v_{az}');
   subplot(4,2,3); cla reset;
   plot(robs*1e-3, pres*1e-2, 'bo','MarkerSize',4); hold on;
   xlim(0,rsel2*1e-3);
   ylabel('p residuals');
   subplot(4,2,4); cla reset;
   plot(robs*1e-3, vres, 'bo','MarkerSize',4); hold on;
   xlim(0,rsel2*1e-3);
   ylabel('v residuals');
   subplot(4,2,5); cla reset;
   plot(hobs(ix2),vres(ix2),'o','MarkerSize',4); hold on;
   xlabel('hours'); ylabel('inner resid');
   subplot(4,2,6); cla reset;
   plot(hobs(ix1),vres(ix1),'o','MarkerSize',4);  hold on;
   xlabel('hours'); ylabel('outer resid');
   subplot(4,2,7); cla reset;
   plot(lobs(ix2),vres(ix2),'o','MarkerSize',4); xdegrees; hold on;
   xlabel('azimuth'); ylabel('inner resid');
   subplot(4,2,8); cla reset;
   plot(lobs(ix1),vres(ix1),'o','MarkerSize',4); xdegrees; hold on;
   xlabel('azimuth'); ylabel('outer resid');
 
end


