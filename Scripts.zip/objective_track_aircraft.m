% objective_track_aircraft.m
% Tracks of Danielle from various data for objective track paper.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Flightlevel data - based on analyse_flightlevel.m %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if isunix
    addpath('~hurricanes/tc_cases/matlab');
else
    addpath('c:/Dokumente und Einstellungen/Hurricanes/matlab');
    addpath('c:/Dokumente und Einstellungen/Hurricanes/tc_cases/matlab');
end

format short g
clear
clear global

flights = {
 '980826U3' ;
 '980827U2' ;
 '980828U2' ;
 '980828U4' ;
 '980829U1' ;
 '980829U2' ;
 '980830U1' ;
 '980830I' ;
 '980827U1' ;
 '980830U2' ;
 '980831U1' ;
 '980831U3' ;
 '980901U1' ;
 '980829H' ;
 '980830H' ;
 '980829I' 
};

nfl = length(flights);

% for ifl = 1 : nfl
% for ifl = 1
ifl = 8;

   flight = flights{ifl};
   
   fname = sprintf('matlab/danielle98_flev');
   
   load(fname);
   load('matlab/Danielle98_nhctrack');
   
   rkm = bin*0.5;
   relwind = 0;  % Iterations for rel winds for wind-based techniques
   
   % Base positions come from the NHC best-track interpolated to time0
   switch flight
      case {'980826U3'}
         time0 = datenum(1998,08,27,03,0,0); flev = 850;
         rmplot = 150; zrplot = 200; vmplot = 40;
         rsel1 =  0e3; rsel2 = 50e3; 
         useleg = [1:8];
         a0h = [ 30; 30e3; 1.3; nan; nan ];
      case {'980827U2'}
         time0 = datenum(1998,08,28,03,0,0); flev = 850;
         rmplot = 150; zrplot = 100; vmplot = 30;
         rsel1 =  0e3; rsel2 = 50e3;
         useleg = [9:18];
         a0h = [ 30; 30e3; 1.5; nan; nan ];
      case {'980828U2'}
         time0 = datenum(1998,08,28,15,0,0); flev = 850;
         rmplot = 150; zrplot = 100; vmplot = 30;
         rsel1 =  0e3; rsel2 = 150e3;  % Big storm!
         useleg = [19:26];
         a0h = [ 25; 80e3; 0.8; nan; nan ];
      case {'980828U4'}
         time0 = datenum(1998,08,29,03,0,0); flev = 850;
         rmplot = 150; zrplot = 100; vmplot = 30;
         rsel1 =  0e3; rsel2 = 150e3;  % Big storm!
         useleg = [27:34];
         a0h = [ 25; 80e3; 0.8; nan; nan ];
      case {'980829U1'}
         time0 = datenum(1998,08,29,15,0,0); flev = 850;
         rmplot = 150; zrplot = 100; vmplot = 30;
         rsel1 =  0e3; rsel2 = 150e3;  % Big storm!
         useleg = [35:42];
         a0h = [ 25; 80e3; 0.8; nan; nan ];
      case {'980830I'}
         time0 = datenum(1998,08,31,00,0,0); flev = 750;
         rmplot = 150; zrplot = 100; vmplot = 30;
         rsel1 =  0e3; rsel2 = 150e3;  % Big storm!
         useleg = [57:64];
         a0h = [ 25; 80e3; 0.8; nan; nan ];
      case {'980829H'}
         time0 = datenum(1998,08,30,00,0,0); flev = 600;
         rmplot = 150; zrplot = 100; vmplot = 30;
         rsel1 =  0e3; rsel2 = 150e3;  % Big storm!
         useleg = [99:118];
         a0h = [ 25; 80e3; 0.8; nan; nan ];
      case {'980830H'}
         time0 = datenum(1998,08,31,03,0,0); flev = 600;
         rmplot = 150; zrplot = 100; vmplot = 30;
         rsel1 =  0e3; rsel2 = 150e3;  % Big storm!
         useleg = [119:124];
         a0h = [ 25; 80e3; 0.8; nan; nan ];
      case {'980829I'}
         time0 = datenum(1998,08,30,00,0,0); flev = 550;
         rmplot = 150; zrplot = 100; vmplot = 30;
         rsel1 =  0e3; rsel2 = 150e3;  % Big storm!
         useleg = [125:133];
         a0h = [ 25; 80e3; 0.8; nan; nan ];
       case {'980827U1'}
         time0 = datenum(1998,08,27,15,0,0); flev = 700;
         rmplot = 150; zrplot = 100; vmplot = 30;
         rsel1 =  0e3; rsel2 = 150e3;  % Big storm!
         useleg = [65:70];
         a0h = [ 25; 80e3; 0.8; nan; nan ];
      case {'980830U2'}
         time0 = datenum(1998,08,31,03,0,0); flev = 700;
         rmplot = 150; zrplot = 100; vmplot = 30;
         rsel1 =  0e3; rsel2 = 150e3;  % Big storm!
         useleg = [71:78];
         a0h = [ 25; 80e3; 0.8; nan; nan ];
      case {'980831U1'}
         time0 = datenum(1998,08,31,15,0,0); flev = 700;
         rmplot = 150; zrplot = 100; vmplot = 30;
         rsel1 =  0e3; rsel2 = 150e3;  % Big storm!
         useleg = [79:86];
         a0h = [ 25; 80e3; 0.8; nan; nan ];
      case {'980831U3'}
         time0 = datenum(1998,09,01,03,0,0); flev = 700;
         rmplot = 150; zrplot = 100; vmplot = 30;
         rsel1 =  0e3; rsel2 = 150e3;  % Big storm!
         useleg = [87:90];
         a0h = [ 25; 80e3; 0.8; nan; nan ];
      case {'980901U1'}
         time0 = datenum(1998,09,01,03,0,0); flev = 700;
         rmplot = 150; zrplot = 100; vmplot = 30;
         rsel1 =  0e3; rsel2 = 150e3;  % Big storm!
         useleg = [91:98];
         a0h = [ 25; 80e3; 0.8; nan; nan ];
otherwise
         disp(sprintf('Unrecognised flight %s', flight));
         break;
   end
   savename = sprintf('matlab/results_flightlevel_%s', flight);
   tclat0 = interp1(nhc_time, nhc_lat, time0); tclon0 = interp1(nhc_time, nhc_lon, time0);
   ut = interp1(nhc_time, nhc_ut, time0); vt = interp1(nhc_time, nhc_vt, time0);
   timeok = ismember(leg, useleg);
   nleg = length(useleg);
   rfit = max(rsel1,1e3) : 1e3 : (rmplot*1e3);
   a0s = [ 0; 0; ut; vt ]; a0h = [ a0h ; a0s ];
   
   % Locate data relative to storm using HRD high-res track
   xrel = (lon - tc_lon)*6370e3*pi/180 .* cos(tc_lat*pi/180);
   yrel = (lat - tc_lat)*6370e3*pi/180;
   rrel = hypot(xrel,yrel);
   lam = mod(atan2(yrel,xrel)*180/pi, 360);
   hr = 24*(time - time0);
   
   % Locate data relative to cartesian plane
   x = (lon - tclon0)*6370e3*pi/180 * cos(tclat0*pi/180);
   y = (lat - tclat0)*6370e3*pi/180;
   
   % Cartesian storm-relative winds
   uxr = ( xrel.*ucr - yrel.*vcr ) ./ rrel;
   vxr = ( yrel.*ucr + xrel.*vcr ) ./ rrel;
   
   % Cartesian earth-relative winds
   uxe = uxr + ut;
   vxe = vxr + vt;
   
   % Inflow angle
   inr = atan2(ucr,vcr)*180/pi;
   
   vm = zeros(nleg,1) + nan; rm = zeros(nleg,1) + nan; 
   for ii = 1 : nleg
      ix = find(leg == useleg(ii)); ytick([-90:45:90]);
      if any(timeok(ix))
         [vm(ii),im] = max(vcr(ix));
         rm(ii) = rrel(ix(im));
      end
   end
   fig(1); clf;
   for ii = 1 : nleg
      ix = find(leg == useleg(ii));
      subplot(ceil(nleg/2),6,3*ii-2); cla;
      plot(rrel(ix)/1e3,z_pnom(ix),'.'); xlim(0,rmplot); yrange(zrplot);
      subplot(ceil(nleg/2),6,3*ii-1); cla;
      plot(rrel(ix)/1e3,vcr(ix),'b.',rrel(ix)/1e3,ucr(ix),'r.'); xylim(0,rmplot,-10,vmplot);
      vline(min(rm)/1e3); vline(max(rm)/1e3); hline(0);
      subplot(ceil(nleg/2),6,3*ii  ); cla;
      plot(rrel(ix)/1e3,inr(ix),'.'); xlim(0,rmplot); ylim(-90,90); 
      ytick([-90:45:90]); hline(0);
   end
   
   % Willoughby-Chelmow track
   
   use = find( ~isnan(uxe) & ~isnan(x) & rsel1 <= rrel & rrel < rsel2 & timeok );
   xobs = x(use); yobs = y(use); 
   tobs = (time(use) - time0)*86400;
   uobs = uxe(use); vobs = vxe(use);
   sigv = 1.0;
   sigdir = min( sigv./hypot(uobs,vobs), pi/2 );
   [awc, errwc] = wi_ch_asyn(xobs,yobs,tobs,uobs,vobs,'auto',sigdir,relwind);
   % Transform into WC coordinates
   xwc = x - awc(1) - (time - time0)*86400*awc(3);
   ywc = y - awc(2) - (time - time0)*86400*awc(4);
   rwc = hypot(xwc,ywc);
   uxrwc = uxe - awc(3); vxrwc = vxe - awc(4);
   ucrwc = ( xwc.*uxrwc + ywc.*vxrwc ) ./ rwc;
   vcrwc = (-ywc.*uxrwc + xwc.*vxrwc ) ./ rwc;
   inrwc = atan2(ucrwc,vcrwc)*180/pi;
   
   vmwc = zeros(nleg,1) + nan; rmwc = zeros(nleg,1) + nan;
   xmwc = zeros(nleg,1) + nan; ymwc = zeros(nleg,1) + nan;
   for ii = 1 : nleg
      ix = find(leg == useleg(ii));
      if any(timeok(ix))
         [vmwc(ii),im] = max(vcrwc(ix));
         rmwc(ii) = rwc(ix(im));
         xmwc(ii) = xwc(ix(im));
         ymwc(ii) = ywc(ix(im));
      end
   end
   
   fig(2); clf;
   for ii = 1 : nleg
      ix = find(leg == useleg(ii));
      subplot(ceil(nleg/2),6,3*ii-2); cla;
      plot(rwc(ix)/1e3,z_pnom(ix),'.'); xlim(0,rmplot); yrange(zrplot);
      subplot(ceil(nleg/2),6,3*ii-1); cla;
      plot(rwc(ix)/1e3,vcrwc(ix),'b.',rwc(ix)/1e3,ucrwc(ix),'r.'); 
      xylim(0,rmplot, -10,vmplot);
      vline(min(rmwc)/1e3); vline(max(rmwc)/1e3); hline(0);
      subplot(ceil(nleg/2),6,3*ii  ); cla;
      plot(rwc(ix)/1e3,inrwc(ix),'.'); xlim(0,rmplot); ylim(-90,90); ytick([-90:45:90]);
      hline(0);
   end
   
   % Simplex track
   use = find( ~isnan(uxe) & ~isnan(x) & rsel1 < rrel & rrel < rsel2 & timeok );
   uv = [uxe(use),vxe(use)];
   xyt = [x(use),y(use),86400*(time(use) - time0)];
   [a,circ] = simplex_track(uv, xyt, a0s, relwind);
   % [aaa,circ] = simplex_track(uv, xyt, a, 1);
   vms = zeros(nleg,1) + nan; rms = zeros(nleg,1) + nan; 
   if any(abs(a) > 1e6)
      a = a + nan;
      disp('**** Simplex fit failed');
   else
      % Transform into simplex-track coordinates
      xs = x - a(1) - (time - time0)*86400*a(3);
      ys = y - a(2) - (time - time0)*86400*a(4);
      rs = hypot(xs,ys); ls = mod(atan2(ys,xs)*180/pi,360);

      uxrs = uxe - a(3); vxrs = vxe - a(4);
      ucrs = ( xs.*uxrs + ys.*vxrs ) ./ rs;
      vcrs = (-ys.*uxrs + xs.*vxrs ) ./ rs;
      inrs = atan2(ucrs,vcrs)*180/pi;
      
      for ii = 1 : nleg
         ix = find(leg == useleg(ii));
         if any(timeok(ix))
            [vms(ii),im] = max(vcrs(ix));
            rms(ii) = rs(ix(im));
         end
      end
      
      fig(4); clf;
      for ii = 1 : nleg
         ix = find(leg == useleg(ii));
         subplot(ceil(nleg/2),6,3*ii-2); cla;
         plot(rs(ix)/1e3,z_pnom(ix),'.'); xlim(0,rmplot); yrange(zrplot);
         subplot(ceil(nleg/2),6,3*ii-1); cla;
         plot(rs(ix)/1e3,vcrs(ix),'b.',rs(ix)/1e3,ucrs(ix),'r.'); 
         xlim(0,rmplot); ylim(-10,vmplot);
         vline(min(rms)/1e3); vline(max(rms)/1e3); hline(0);
         subplot(ceil(nleg/2),6,3*ii  ); cla;
         plot(rs(ix)/1e3,inrs(ix),'.'); xlim(0,rmplot); ylim(-90,90); ytick([-90:45:90]);
         hline(0);
      end
   end
   
   % Fit Holland pressure profile and track-find.
   global f0
   f0 = cor(tclat0);
   use = find(~isnan(z_pnom) & rsel1 <= rrel & rrel < rsel2 & timeok);
   xobs = x(use); yobs = y(use); robs = hypot(xobs,yobs);
   tobs = (time(use) - time0)*86400;
   zobs = z_pnom(use);
   Tbar = nanmean(Ta(use)) + 273.15;
   xyt = [ xobs, yobs, tobs ];
   sigz = 10*ones(size(xobs));
   
   a0h(4) = min(zobs); a0h(5) = Tbar;
   ia = [ 1 1 1 1 0 1 1 1 1 ]';  % Don't fit environmental temperature
   [ah,cov,chisq] = mrqmin_multi(xyt, zobs, sigz, a0h, ia, @holland_z_xyuv, 50, 10);
   
   xh = x - ah(6) - (time - time0)*86400*ah(8);
   yh = y - ah(7) - (time - time0)*86400*ah(9);
   rh = hypot(xh,yh); lh = mod(atan2(yh,xh)*180/pi,360);
   uxrh = uxe - ah(8); vxrh = vxe - ah(9);
   ucrh = ( xh.*uxrh + yh.*vxrh ) ./ rh;
   vcrh = (-yh.*uxrh + xh.*vxrh ) ./ rh;
   inrh = atan2(ucrh,vcrh)*180/pi;
   zh = holland_z(rh,ah(1:5));
   zfh = holland_z(rfit,ah(1:5));
   vfh = holland_vz(rfit,ah(1:5));
  
   vmh = zeros(nleg,1) + nan; rmh = zeros(nleg,1) + nan; 
   xmh = zeros(nleg,1) + nan; ymh = zeros(nleg,1) + nan; 
   for ii = 1 : nleg
      ix = find(leg == useleg(ii));
      if any(timeok(ix))
         [vmh(ii),im] = max(vcrh(ix));
         rmh(ii) = rh(ix(im));
         xmh(ii) = xh(ix(im));
         ymh(ii) = yh(ix(im));
      end
   end
   
   fig(5); clf;
   for ii = 1 : nleg
      ix = find(leg == useleg(ii));
      subplot(ceil(nleg/2),6,3*ii-2); cla;
      plot(rh(ix)/1e3,z_pnom(ix),'.'); hold on;
      plot(rfit/1e3,zfh,'r-','LineWidth',2); xlim(0,rmplot); yrange(zrplot);
      subplot(ceil(nleg/2),6,3*ii-1); cla;
      plot(rh(ix)/1e3,vcrh(ix),'b.',rh(ix)/1e3,ucrh(ix),'r.'); hold on;
      plot(rfit/1e3,vfh,'r-','LineWidth',2); xlim(0,rmplot); ylim(-10,40);
      vline(min(rms)/1e3); vline(max(rms)/1e3); hline(0);
      subplot(ceil(nleg/2),6,3*ii  ); cla;
      plot(rh(ix)/1e3,inrh(ix),'.'); xlim(0,rmplot); ylim(-90,90); ytick([-90:45:90]);
      hline(0);
      if ii == 1
         title([ hurr '  ' flight ]);
      end
   end

   fig(6); clf;
   plot(rm/1e3,vm,'go', rms/1e3,vms,'bs', rmh/1e3,vmh,'r*', ...
        rmwc/1e3,vmwc,'k+');
   title('vcr_{max} and rmw for flight data various tracks');
   xlabel('r_{max} (km)'); ylabel('v_{max} (m/s)');
   
   % Compare tracks to low-res HRD, high-res HRD, and NHC
 % load('matlab/danielle98_hrdtrack');
 % load('matlab/danielle98_ctr');
 % hrd_x = (hrd_lon - tclon0)*6370e3*pi/180 * cos(tclat0*pi/180);
 % hrd_y = (hrd_lat - tclat0)*6370e3*pi/180;
 % hrd2_x = (tc_lon(timeok) - tclon0)*6370e3*pi/180 * cos(tclat0*pi/180);
 % hrd2_y = (tc_lat(timeok) - tclat0)*6370e3*pi/180;
 % ctrok = find( min(time(timeok)) <= ctr_time & ctr_time <= max(time(timeok)) );
 % ctr_x = (ctr_lon(ctrok) - tclon0)*6370e3*pi/180 * cos(tclat0*pi/180);
 % ctr_y = (ctr_lat(ctrok) - tclat0)*6370e3*pi/180;
   nhc_x = (nhc_lon - tclon0)*6370e3*pi/180 * cos(tclat0*pi/180);
   nhc_y = (nhc_lat - tclat0)*6370e3*pi/180;
   sim_x = a(1) + ([min(time(timeok)); max(time(timeok))] - time0)*86400*a(3);
   sim_y = a(2) + ([min(time(timeok)); max(time(timeok))] - time0)*86400*a(4);
   hol_x = ah(6) + ([min(time(timeok)); max(time(timeok))] - time0)*86400*ah(8);
   hol_y = ah(7) + ([min(time(timeok)); max(time(timeok))] - time0)*86400*ah(9);
   wc_x = awc(1) + ([min(time(timeok)); max(time(timeok))] - time0)*86400*awc(3);
   wc_y = awc(2) + ([min(time(timeok)); max(time(timeok))] - time0)*86400*awc(4);
   
   fig(7); clf;
   hold on; xylim(2e5); set(gca,'DataAspectRatio',[1 1 1]);
 % plot(hrd_x,hrd_y,'r-'); 
 % plot(interp1(hrd_time,hrd_x,time0+[-2:2]/8),interp1(hrd_time,hrd_y,time0+[-2:2]/8),'ro');
 % plot(hrd2_x,hrd2_y,'k-');
   plot(nhc_x,nhc_y,'b-');
 % plot(ctr_x,ctr_y,'c-o');
   plot(interp1(nhc_time,nhc_x,time0+[-2:2]/8),interp1(nhc_time,nhc_y,time0+[-2:2]/8),'bo');
   plot(sim_x,sim_y,'g-');
   plot(a(1) + [-3 0 3]*3600*a(3), a(2) + [-3 0 3]*3600*a(4), 'go');
   plot(hol_x,hol_y,'m-');
   plot(ah(6) + [-3 0 3]*3600*ah(8), ah(7) + [-3 0 3]*3600*ah(9), 'mo');
   plot(wc_x,wc_y,'g-');
   plot(awc(1) + [-3 0 3]*3600*awc(3), awc(2) + [-3 0 3]*3600*awc(4), 'g+');
   hline(0); vline(0);
   title(sprintf('Various tracks: %s %s %d hPa',hurr,flight, flev));
   
   save(savename, 'a', 'a0h', 'a0s', 'ah', 'awc', 'errwc', 'flev', ...
        'flight','useleg');

   fig(8); clf;
   subplot(2,1,1); cla reset;
   plot(hr(timeok),z_pnom(timeok)); ylabel('z_{pnom}'); hline(ah(4),':');
   title(sprintf('%s Base time %s',flight,datestr(time0)));
   subplot(2,1,2); cla reset;
   plot(hr(timeok),hypot(uxe(timeok),vxe(timeok))); ylabel('Wind speed'); hline(ah(1),':');
   xlabel('Hours from base');

   disp(sprintf('WC  %.2f %.2f %.2f %.2f', ...
        mean(rmwc)/1e3, 2*std(rmwc)/1e3,mean(vmwc),2*std(vmwc)));
   disp(sprintf('MHG %.2f %.2f %.2f %.2f', ...
        mean(rms)/1e3, 2*std(rms)/1e3,mean(vms),2*std(vms)));
   disp(sprintf('TPF %.2f %.2f %.2f %.2f', ...
        mean(rmh)/1e3, 2*std(rmh)/1e3,mean(vmh),2*std(vmh)));

   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   %% Radial temperature gradient %%
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   if 0
      rsel1 = 0; rsel2 = 200e3; 
      rrfit = [max(1e3,rsel1) : 1e3 : rsel2]';

      use = find(timeok & ~isnan(Ta) & rsel1 <= rh & rh < rsel2 );
      xobs = xh(use); yobs = yh(use); robs = hypot(xobs,yobs);
      tobs = (time(use) - time0)*86400;
      zobs = z_pnom(use); 
      Tobs = Ta(use) + (zobs - zobs(1))*0.01;
      Tobs = Ta(use);
      nobs = length(use);

      sigT = ones(size(robs));
      a0 = [ 25, 50e3, 1.8, 16 ]';
      ia = ones(4,1);
      [aT,cov,chisq] = mrqmin(robs, Tobs, sigT, a0, ia, @holland_T, 30, 10);

      Tafit = holland_T(rrfit,aT);

      fig(9); clf;
      if 0
      subplot(2,1,1); cla reset;
      plot(robs,Tobs,'b.'); hold on;
      plot(rrfit,Tafit,'r-','LineWidth',2);
      xlim(0,rsel2);
      xlabel('Radius (km)'); ylabel('T_a (K)');
      title(sprintf('%s %s a_t=[%.1f %.1f %.1f %.1f]',hurr,flight,aT./[1;1e3;1;1]));
      end

      rsel2 = 100e3;
      use = find(timeok & ~isnan(Ta) & rsel1 <= rh & rh < rsel2 );
      use = use(1 : 5 : length(use)); nobs = length(use);
      xobs = xh(use); yobs = yh(use); robs = hypot(xobs,yobs);
      tobs = (time(use) - time0)*86400;
      zobs = z_pnom(use); 
      Tobs = Ta(use) + (zobs - zobs(1))*0.01;
      Tobs = Ta(use);
      Tbar = nanmean(Tobs) + 273.15;

      ds = 10e3;
      [xg,yg] = meshgrid( -rsel2-ds:ds:rsel2+ds, -rsel2-ds:ds:rsel2+ds ); rg = hypot(xg,yg);

      sigbT = 2;          % Background errors for swf
      sigoT = 1;          % Observation error for swf
      Lrad = 30e3;          % Radial length scales (m)
      Laz  = pi/3;          % Azimuthal length scales (radians)
      Tb = reshape(holland_T(rg, aT), size(xg));

      [Tanal Terr1] = tcsi(xg,yg,Tb,xobs,yobs,Tobs,Lrad,Laz,sigbT,sigoT);

   %  subplot(2,1,2); cla reset;
      contourf(xg/1e3,yg/1e3,Tanal,floor(min(Tobs)):ceil(max(Tobs)),'k'); hold on; colorbar('vert');
      set(gca,'DataAspectRatio',[1 1 1]);
      h = text(xobs(1:5:nobs)/1e3,yobs(1:5:nobs)/1e3,num2str(Tobs(1:5:nobs),'%.1f'));
      set(h, 'HorizontalAlignment','center','VerticalAlignment','middle','Color',[0 0 0]);
      set(h,'FontSize',8);
      plot(-ah(6)/1e3,-ah(7)/1e3,'w+','MarkerSize',20,'LineWidth',3);
      title(sprintf('%s %s a_t=[%.1f %.1f %.1f %.1f]',hurr,flight,aT./[1;1e3;1;1]));
      xlabel('x (km)'); ylabel('y (km)');
      hline(0); vline(0);
   end

   if 0 
    % cprint([5 7]); 
      bwprint(8); 
   end;

   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   %% Fit Willoughby parametric wind profiles  %%
   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   na = 9;
   ia  = [ 1 1 1 0 1 1 0 0 0 ]';
   L2 = 500e3; Lb = 10e3;
   rrfit = [0 : 1e3 : 150e3];

   global w2v_rmhat w2v_rmscal w2v_L1hat w2v_L1scal w2v_L2hat w2v_L2scal

   w2v_rmhat = 25e3; w2v_rmscal = 1;
   w2v_L1hat = 3e4;  w2v_L1scal = 1;
   w2v_L2hat =  L2;  w2v_L2scal = 0;
   switch flev
       case {850}
          znom = 1500;
       case {750}
          znom = 2600;
       case {700}
          znom = 3000;
       case {600}
          znom = 4200;
       case {550}
          znom = 4900;
       otherwise
          znom = nan;
    end
 

 % use = find(rsel1 < rh & rh < rsel2 & ~isnan(vcrh) & timeok );
   use = find(~isnan(vcrh) & timeok );
   xobs = xh(use); yobs = yh(use); robs = rh(use); lobs = lh(use);
   
   xobs = xs(use); yobs = ys(use); robs = rs(use); lobs = ls(use);
   zobs = z_pnom(use); Tobs = Ta(use)+273.15;
   pobs = flev*100*exp(9.80665*(zobs-znom)./(287*Tobs));
   pmin = mean(pobs(find(robs < 5e3)));
   if isnan(pmin)
      pmin = mean(pobs(find(robs < 10e3)));
   end
   uobs = ucrh(use); vobs = vcrh(use);
   rhoobs = pobs./(287*Tobs); hobs = hr(use);
   nobs = length(use);
   sigv = 5*ones(nobs,1);
   sigr = 1e3*ones(nobs,1);

   r1 = [robs ]; v1 = [vobs]; sig1 = [sigv];
   a0 = [ 15, 30e3, 15, L2, 25e3, 1.5, pmin, nanmean(Tobs) Lb ]';
   [awv,cov,chisqwv] = mrqmin(r1, v1, sig1, a0, ia, @willoughby2_v, 100, 10);
   nf = nobs - sum(ia);

   pgfit = willoughby2_p_numerical(rrfit,awv);
   vvfit = willoughby2_v(rrfit,awv);
   pres = pobs - willoughby2_p_numerical(robs,awv);
   vres = vobs - willoughby2_v(robs,awv);

   clear global w2v_rmhat w2v_rmscal w2v_L1hat w2v_L1scal w2v_L2hat w2v_L2scal

   save(savename);
   % load(savename);

   ix1 = find(15e3 < robs & robs < 40e3); ix2 = find(50e3 < robs & robs < 100e3);
   fig(10); clf;
   subplot(4,2,1); cla reset;
   plot(robs*1e-3,pobs*1e-2,'bo','MarkerSize',4); hold on;
   plot(rrfit*1e-3,pgfit*1e-2,'r-','LineWidth',2);
   xlim(0,rsel2*1e-3); yrange(80,0,0);
   title(sprintf('z=%.0f, \\chi^2/n_f=%.3f, %s %s',znom,chisq/nf,hurr,flight));
   ylabel('pressure');
   subplot(4,2,2); cla reset;
   plot(robs*1e-3,vobs,'bo','MarkerSize',4); hold on;
   plot(rrfit*1e-3,vvfit,'r-','LineWidth',2);
   xlim(0,rsel2*1e-3); yrange(80,0,0);
   title(sprintf('a=[%.1f %.1f %.1f %.1f %.1f %.2f %.1f]',awv(1:7)./[1 1e3 1 1e3 1e3 1 1e2]'));
   ylabel('v_{az}');
   subplot(4,2,3); cla reset;
   plot(robs*1e-3, pres*1e-2, 'bo','MarkerSize',4); hold on;
   xlim(0,rsel2*1e-3);
   ylabel('p residuals');
   subplot(4,2,4); cla reset;
   plot(robs*1e-3, vres, 'bo','MarkerSize',4); hold on;
   xlim(0,rsel2*1e-3);
   ylabel('v residuals');
   subplot(4,2,5); cla reset;
   plot(hobs(ix2),vres(ix2),'o','MarkerSize',4); hold on;
   xlabel('hours'); ylabel('inner resid');
   subplot(4,2,6); cla reset;
   plot(hobs(ix1),vres(ix1),'o','MarkerSize',4);  hold on;
   xlabel('hours'); ylabel('outer resid');
   subplot(4,2,7); cla reset;
   plot(lobs(ix2),vres(ix2),'o','MarkerSize',4); xdegrees; hold on;
   xlabel('azimuth'); ylabel('inner resid');
   subplot(4,2,8); cla reset;
   plot(lobs(ix1),vres(ix1),'o','MarkerSize',4); xdegrees; hold on;
   xlabel('azimuth'); ylabel('outer resid');
 
end



%%% FLIGHT TRACK
load('results_flightlevel_980830I');
subplot(1,2,1);
plot(xrel(use),yrel(use));
set(gca,'DataAspectRatio',[1,1,1]);
title('Flight track, 19980830I');
xlabel('West-East distance in m');
ylabel('North-South distance in m');
load('results_flightlevel_980830H');
subplot(1,2,2);
plot(xrel(use),yrel(use));
set(gca,'DataAspectRatio',[1,1,1]);
title('Flight track, 19980830H');
xlabel('West-East distance in m');
ylabel('North-South distance in m');



%%% picture for thesis
nhc_x = (nhc_lon - tclon0)*6370e3*pi/180 * cos(tclat0*pi/180);
nhc_y = (nhc_lat - tclat0)*6370e3*pi/180;
sim_x = a(1) + ([min(time(timeok)); max(time(timeok))] - time0)*86400*a(3);
sim_y = a(2) + ([min(time(timeok)); max(time(timeok))] - time0)*86400*a(4);
hol_x = ah(6) + ([min(time(timeok)); max(time(timeok))] - time0)*86400*ah(8);
hol_y = ah(7) + ([min(time(timeok)); max(time(timeok))] - time0)*86400*ah(9);
wc_x = awc(1) + ([min(time(timeok)); max(time(timeok))] - time0)*86400*awc(3);
wc_y = awc(2) + ([min(time(timeok)); max(time(timeok))] - time0)*86400*awc(4);

load('results_flightlevel_980830I');
subplot(1,2,1);
hold on; xylim(2e5); set(gca,'DataAspectRatio',[1 1 1]);
   plot(nhc_x,nhc_y,'b-');
   plot(interp1(nhc_time,nhc_x,time0+[-2:2]/8),interp1(nhc_time,nhc_y,time0+[-2:2]/8),'bo');
   plot(sim_x,sim_y,'g-');
   plot(a(1) + [-3 0 3]*3600*a(3), a(2) + [-3 0 3]*3600*a(4), 'go');
   plot(hol_x,hol_y,'m-');
   plot(ah(6) + [-3 0 3]*3600*ah(8), ah(7) + [-3 0 3]*3600*ah(9), 'mo');
   plot(wc_x,wc_y,'g-');
   plot(awc(1) + [-3 0 3]*3600*awc(3), awc(2) + [-3 0 3]*3600*awc(4), 'g+');
   hline(0); vline(0);
   xlim(-3e4,3e4);
   ylim(-4e4,4e4);
   title('19980830I');
load('results_dropsonde_19980830HI');
subplot(1,2,2);
hold on; xylim(2e5); set(gca,'DataAspectRatio',[1 1 1]);
   plot(nhc_x,nhc_y,'b-');
   plot(interp1(nhc_time,nhc_x,time0+[-2:2]/8),interp1(nhc_time,nhc_y,time0+[-2:2]/8),'bo');
   plot(sim_x,sim_y,'g-');
   plot(a(1) + [-3 0 3]*3600*a(3), a(2) + [-3 0 3]*3600*a(4), 'go');
   plot(hol_x,hol_y,'m-');
   plot(ah(6) + [-3 0 3]*3600*ah(8), ah(7) + [-3 0 3]*3600*ah(9), 'mo');
   plot(wc_x,wc_y,'g-');
   plot(awc(1) + [-3 0 3]*3600*awc(3), awc(2) + [-3 0 3]*3600*awc(4), 'g+');
   hline(0); vline(0);
   xlim(-3e4,3e4);
   ylim(-4e4,4e4);
   title('Surface track');
   
   
   
   