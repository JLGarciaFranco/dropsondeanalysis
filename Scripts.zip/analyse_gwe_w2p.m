if isunix
    addpath('~hurricanes/tc_cases/matlab');
else
    addpath('c:/Dokumente und Einstellungen/Hurricanes/matlab');
end

format short g
clear
clear global
global f0
global w2p_rmhat w2p_rmscal w2p_L1hat w2p_L1scal w2p_L2hat w2p_L2scal

w2p_rmhat = 35e3; w2p_rmscal = 1;
w2p_L1hat = 3e4;  w2p_L1scal = 1;
w2p_L2hat = 3e5;  w2p_L2scal = 0;

load('matlab/Danielle_19980830HI_dropsonde_10_hydroadj');

f0 = cor(tclat0);
hr = 24*(ztime - time0);
hrT = 24*(ztimeT - time0);

% flightlevel p-track: 0 for all
tracktype = 0;

if tracktype == 0  % Relative to flight-level track
   savename = 'matlab/results_gwe_w2p_hy_fl';
   load('matlab/results_flightlevel_980830I','ah');
   xt = ah(6) + zeros(size(zx,1), 1) - 0.0e3;  %%!!!!!!!!!!!!!!!!!!!
   yt = ah(7) + zeros(size(zx,1), 1) - 0.0e3
   ut = ah(8) + zeros(size(zx,1), 1); vt = ah(9) + zeros(size(zx,1), 1); 
   timeok = ones(size(hr));
   trackcom = 'aircraft-p track';
   nzfit = 31;
   Lb = 10e3; L2 = 500e3;
end

% Convert to storm-relative coordinates
oo = ones(1, size(zx,2));
xrel = zx - xt*oo - (ut*oo).*hr*3600;
yrel = zy - yt*oo - (vt*oo).*hr*3600;
rrel = hypot(xrel,yrel);
lamrel = mod(atan2(yrel,xrel)*180/pi, 360);  % Anticlockwise from +x axis
xrelT = zxT - xt(1) - ut(1)*hrT*3600;
yrelT = zyT - yt(1) - vt(1)*hrT*3600;
rrelT = hypot(xrelT,yrelT);
lamrelT = mod(atan2(yrelT,xrelT)*180/pi, 360);  % Anticlockwise from +x axis
uxrel = zuex - ut*oo;   % Storm-relative cartesian winds.
vxrel = zvex - vt*oo;
ucrel = ( uxrel.*xrel + vxrel.*yrel ) ./ rrel;  % Storm-relative cylindrical winds
vcrel = ( vxrel.*xrel - uxrel.*yrel ) ./ rrel;
clear oo

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Check hydrostatic discrepancy against inward path slant %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fig(1); clf;
use = find(timeok(2,:) &  0e3 < rrel(2,:) & rrel(2,:) < 15e3);
plot(rrel(301,use)-rrel(2,use),phyd_adj(use)-pspl_adj(use),'k+'); hold on;
use = find(timeok(2,:) & 15e3 < rrel(2,:) & rrel(2,:) < 50e3);
plot(rrel(301,use)-rrel(2,use),phyd_adj(use)-pspl_adj(use),'bo');
use = find(timeok(2,:) & 50e3 < rrel(2,:) & rrel(2,:) < 100e3);
plot(rrel(301,use)-rrel(2,use),phyd_adj(use)-pspl_adj(use),'rx');
hline(0);
xlabel('Radial displacement (m)');
ylabel('sfcp_{hyd2} - sfcp_{splash} (Pa)');
title(sprintf('%s %s', event, trackcom));
legend('0-15km','15-50km','50-100km',4);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Fit Willoughby parametric pressure profiles at each 100 m level %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
zfit = 100*[0 : nzfit-1]';
%%%% Check radius at which data is available - maybe rsel2 = 200 km ???
rsel1 = 0e3; rsel2 = 200e3;
rrfit = [max(1e3,rsel1):1e3:rsel2]';
nrrfit = length(rrfit); drrfit = rrfit(2) - rrfit(1);

ppfit = zeros(nzfit,nrrfit) + nan;
vgfit = zeros(nzfit,nrrfit) + nan;
chisqwp = zeros(nzfit,1) + nan;
nobs = zeros(nzfit,1) + nan;
na = 9;
awp = zeros(nzfit,na) + nan;

fig(2); clf;
for kk = 1 : nzfit  
   disp(sprintf('kk = %d', kk));
   iz = find(zz == zfit(kk));
   use = find(rsel1 < rrel(iz,:) & rrel(iz,:) < rsel2 & ~isnan(zuex(iz,:)) & timeok(iz,:) );
   rpobs = rrelT(use)';   % Radii of p, T, etc
   lpobs = lamrelT(use)';
   ruobs = rrel(iz,use)';  % Radii of winds
   luobs = lamrel(iz,use)';
   pobs = zp(iz,use)'; 
   uobs = ucrel(iz,use)'; vobs = vcrel(iz,use)'; Tobs = zTv(iz,use)';
   rhoobs = pobs./(287.04*Tobs); 
   lobs = lamrel(iz,use)'; hobs = hr(iz,use)';
   zobs = zfit(kk); nobs(kk) = length(use);
   sigp = 100*ones(nobs(kk),1);
   sigr = 1e3*ones(nobs(kk),1); 
%  pobs = pobs-90*hobs;  %%!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
   if tracktype == 0
      % Change a0 to match storm being analysed.
      a0 = [ 9 30e3 24 L2 30e3 1.0 min(pobs) nanmean(Tobs) Lb ]';
      ia = [ 1 1 1 0 0 1 1 0 0 ]';
   end
   [a2,chisq,pres,vres,ppp,vvv] = ...
      fit_gwe_w2p_extra(rpobs,pobs,sigr,sigp,a0,ia,rrfit,1, ...
         trackcom,hobs,luobs,rhoobs,ruobs,uobs,vobs,zobs,1);
   myeps(2, sprintf('fit_gwe_w2p_%04d_thesis',zfit(kk)), [10 12]);
   %myjpeg(2, sprintf('fit_gwe_w2p_%04d',zfit(kk)), [20 20]);

   awp(kk,:) = a2'; chisqwp(kk) = chisq;
   ppfit(kk,:) = ppp'; 
   vgfit(kk,:) = vvv';
end

% save(savename)
% load(savename)

nr = 5; nc = 6;

fig(1); clf;
set(gcf,'PaperPosition',[1 2 20 24]);
for kk = 1 : min(nr*nc,nzfit)
   iz = find(zz == zfit(kk));
   use = find(rsel1 < rrel(iz,:) & rrel(iz,:) < rsel2 & ~isnan(zuex(iz,:)) & timeok(iz,:) );
   rpobs = rrelT(use)';   % Radii of p, T, etc
   ruobs = rrel(iz,use)';  % Radii of winds
   pobs = zp(iz,use)'; 
   uobs = ucrel(iz,use)'; vobs = vcrel(iz,use)'; Tobs = zTv(iz,use)';
   rhoobs = pobs./(287.04*Tobs); 
   lobs = lamrel(iz,use)'; hobs = hr(iz,use)';
   zobs = zfit(kk); nobs(kk) = length(use);
   subplot(nr,nc,kk); cla;
   plot(rpobs*1e-3,pobs*1e-2,'bo','MarkerSize',4); hold on;
   plot(rrfit*1e-3,ppfit(kk,:)*1e-2,'r-');
   xlim(0,rsel2*1e-3); yrange(80,0,0);
   if (kk == 3), title([event ' Dropsonde vaz: Obs and Fitted']); end
   if (kk <= (nr-1)*nc); noxlab; else xlabel('Radius (km)'); end;
   if (mod(kk,6) == 1), ylabel('vaz (m/s)'); end;
   h = reltext(0.95,0.9,sprintf('%.0fm',zfit(kk)));
   set(h,'HorizontalAlignment','right','Fontsize',8);
end

pscal = [ 1 1e-3 1 1e-3 1e-3 1 1e-2 1 ]';
ptit = { 'vm1', 'L1', 'vm2','L2','rm', 'n1', 'pc', 'Tv' }';
fig(2); clf;
set(gcf,'PaperPosition',[2 2 12 10]);
for ii = 1 : 8
   subplot(2,5,ii); cla reset; 
   plot(awp(:,ii)*pscal(ii),zfit*1e-3,'b-'); hold on;
 % plot(awv(:,ii)*pscal(ii),zfit*1e-3,'r-'); 
   ylim(0,4.2); 
   if mod(ii,5) ~= 1, set(gca,'YTickLabel',[]); else ylabel('z (km)'); end
   xlabel(ptit(ii));
end
subplot(2,5,9); cla reset;
plot(awp(:,1) + awp(:,3),zfit/1e3,'b-'); hold on; ylim(0,4.2);
% plot(awv(:,1) + awv(:,3),zfit/1e3,'r-'); 
xlabel('vm1 + vm2'); set(gca,'YTickLabel',[]);
subplot(2,5,10); cla reset;
plot(chisqwp./(nobs - sum(ia)),zfit/1e3,'b-'); hold on; ylim(0,4.2);
% plot(chisqwv,zfit/1e3,'r-'); 
xlabel('\chi^2/n_f'); set(gca,'YTickLabel',[]);

fig(3); clf;
set(gcf,'PaperPosition',[1 2 20 24]);
for kk = 1 : nr*nc
   iz = find(zz == zfit(kk));
   use = find(rsel1 < rrel(iz,:) & rrel(iz,:) < rsel2 & ~isnan(zuex(iz,:)) & timeok(iz,:) );
   rpobs = rrelT(use)';   % Radii of p, T, etc
   ruobs = rrel(iz,use)';  % Radii of winds
   pobs = zp(iz,use)'; 
   uobs = ucrel(iz,use)'; vobs = vcrel(iz,use)'; Tobs = zTv(iz,use)';
   rhoobs = pobs./(287.04*Tobs); 
   lobs = lamrel(iz,use)'; hobs = hr(iz,use)';
   zobs = zfit(kk); nobs(kk) = length(use);
   subplot(nr,nc,kk); cla;
   plot(ruobs*1e-3,vobs,'bo','MarkerSize',4); hold on;
   plot(rrfit*1e-3,vgfit(kk,:),'r-');
   xlim(0,rsel2*1e-3); ylim(-10,80);
   if (kk == 3), title([event ' Dropsonde Obs p and Fitted p']); end
   if (kk < (nr-1)*nc); noxlab; else xlabel('Radius (km)'); end;
   if (mod(kk,nc) == 1), ylabel('p (hPa)'); end;
   h = reltext(0.95,0.9,sprintf('%.0fm',zfit(kk)));
   set(h,'HorizontalAlignment','right','Fontsize',8);
end

fig(4); clf;
set(gcf,'PaperPosition',[1 2 20 24]);
for kk = 1 : nr*nc
   iz = find(zz == zfit(kk));
   use = find(rsel1 < rrel(iz,:) & rrel(iz,:) < rsel2 & ~isnan(zuex(iz,:)) & timeok(iz,:) );
   rpobs = rrelT(use)';   % Radii of p, T, etc
   ruobs = rrel(iz,use)';  % Radii of winds
   pobs = zp(iz,use)'; 
   uobs = ucrel(iz,use)'; vobs = vcrel(iz,use)'; Tobs = zTv(iz,use)';
   rhoobs = pobs./(287.04*Tobs); 
   lobs = lamrel(iz,use)'; hobs = hr(iz,use)';
   zobs = zfit(kk); nobs(kk) = length(use);
   pres = pobs - willoughby2_p_numerical(rpobs,awp(kk,:)');
   subplot(nr,nc,kk); cla;
   plot(rpobs*1e-3,pres*1e-2,'bo','MarkerSize',4); hold on;
   hline(0,'r');
   xlim(0,rsel2*1e-3); yrange(6,0,0);
   if (kk == 3), title([event ' Dropsonde p: residuals']); end
   if (kk <= (nr-1)*nc); noxlab; else xlabel('Radius (km)'); end;
   if (mod(kk,nc) == 1), ylabel('p (hPa)'); end;
   h = reltext(0.95,0.9,sprintf('%.0fm',zfit(kk)));
   set(h,'HorizontalAlignment','right','Fontsize',8);
end

fig(5); clf;
set(gcf,'PaperPosition',[1 2 20 24]);
for kk = 1 : nr*nc
   iz = find(zz == zfit(kk));
   use = find(rsel1 < rrel(iz,:) & rrel(iz,:) < rsel2 & ~isnan(zuex(iz,:)) & timeok(iz,:) );
   rpobs = rrelT(use)';   % Radii of p, T, etc
   ruobs = rrel(iz,use)';  % Radii of winds
   pobs = zp(iz,use)'; 
   uobs = ucrel(iz,use)'; vobs = vcrel(iz,use)'; Tobs = zTv(iz,use)';
   rhoobs = pobs./(287.04*Tobs); 
   lobs = lamrel(iz,use)'; hobs = hr(iz,use)';
   zobs = zfit(kk); nobs(kk) = length(use);
   pres = pobs - willoughby2_p_numerical(rpobs,awp(kk,:)');
   vres = vobs - willoughby2_v(ruobs,awp(kk,:)');
   ix = find(15e3 < ruobs & ruobs < 40e3);
   vresbar(kk) = mean(vres(ix));
   subplot(nr,nc,kk); cla reset;
   plot(ruobs*1e-3,vres,'bo','MarkerSize',4); hold on;
   hline(0,'r');
   xlim(0,rsel2*1e-3); %yrange(20,0,0);
   if (kk == 3), title([event ' Dropsonde vgr Residuals from p fits']); end
   if (kk <= (nr-1)*nc); noxlab; else xlabel('Radius (km)'); end;
   if (mod(kk,nc) == 1), ylabel('v (m/s)'); end;
   h = reltext(0.95,0.9,sprintf('%.0fm',zfit(kk)));
   set(h,'HorizontalAlignment','right','Fontsize',8);
end

% Check residuals against azimuth
b = zeros(nzfit,3);
rmn = 0e3; rmx = 50e3; yl = 3;
% rmn = 50e3; rmx = 100e3; yl = 2;
fig(6); clf;
set(gcf,'PaperPosition',[1 2 20 24]);
for kk = 1 : nr*nc
   iz = find(zz == zfit(kk));
   use = find(rmn < rrel(iz,:) & rrel(iz,:) < rmx & ~isnan(zuex(iz,:)) & timeok(iz,:) );
   rpobs = rrelT(use)';   % Radii of p, T, etc
   ruobs = rrel(iz,use)';  % Radii of winds
   pobs = zp(iz,use)'; 
   uobs = ucrel(iz,use)'; vobs = vcrel(iz,use)'; Tobs = zTv(iz,use)';
   rhoobs = pobs./(287.04*Tobs); 
   lobs = lamrel(iz,use)'; hobs = hr(iz,use)';
   zobs = zfit(kk); nobs(kk) = length(use);
   pres = pobs - willoughby2_p_numerical(rpobs,awp(kk,:)');
   X = [ ones(size(lobs)) cos(lobs*pi/180) sin(lobs*pi/180) ];
   b(kk,:) = regress(pres,X)';
   
   subplot(nr,nc,kk); cla;
   plot(lobs,pres*1e-2,'bo','MarkerSize',4); hold on;
   plot(lobs,X*(b(kk,:)')*1e-2,'r*','MarkerSize',4); 
   xlim(0,360); xtick(0:90:360); ylim(-yl,yl);
   if (kk == 3), title([event ' Dropsonde p Residuals']); end
   if (kk <= (nr-1)*nc); noxlab; else xlabel('Azimuth (^o)'); end;
   if (mod(kk,nr) == 1), ylabel('pres (hPa)'); end;
   h = reltext(0.95,0.9,sprintf('%.0fm',zfit(kk)));
   set(h,'HorizontalAlignment','right','Fontsize',8);
end

% load(savename)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%&& Monte-Carlo Willoughby v fits %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%&&

nmc = 200; na = 9;
ppfitmc = zeros(nzfit,nmc,nrrfit) + nan;
vgfitmc = zeros(nzfit,nmc,nrrfit) + nan;
awpmc = zeros(nzfit,nmc,na) + nan;
chisqwpmc = zeros(nzfit,nmc) + nan;
sigpert = 100;
bootstrap = 0;

if bootstrap, savenamemc = sprintf('%s_bs', savename);
else          savenamemc = sprintf('%s_pert', savename);
end

for kk = 2 : nzfit
   disp(sprintf('kk = %d', kk));
   iz = find(zz == zfit(kk));
   use = find(rsel1 < rrel(iz,:) & rrel(iz,:) < rsel2 & ~isnan(zuex(iz,:)) & timeok(iz,:) );
   rpobs = rrelT(use)';   % Radii of p, T, etc
   lpobs = lamrelT(use)';
   ruobs = rrel(iz,use)';  % Radii of winds
   luobs = lamrel(iz,use)';
   pobs = zp(iz,use)'; 
   uobs = ucrel(iz,use)'; vobs = vcrel(iz,use)'; Tobs = zTv(iz,use)';
   rhoobs = pobs./(287*Tobs); hobs = hr(iz,use)';
   zobs = zfit(kk); nobs(kk) = length(use);
   sigp = 100*ones(nobs(kk),1);
   sigr = 1e3*ones(nobs(kk),1);

   a0 = awp(kk,:)';
   ia = [ 1 1 0 0 1 1 1 0 0 ]';   % Don't fit v2, L2, Tbar or Lb

   if all(~isnan(a0))
      for ii = 1 : nmc
         if bootstrap
            iboot = ceil( nobs(kk)*rand(nobs(kk),1) );
            rpo = rpobs(iboot);
            ruo = ruobs(iboot);
            po = pobs(iboot);
            ho = hobs(iboot); luo = luobs(iboot); so = rhoobs(iboot); 
            uo = uobs(iboot); vo = vobs(iboot);
         else
            rpo = rpobs;
            ruo = ruobs;
            po = pobs + sigpert*randn(nobs(kk),1);
            ho = hobs; luo = luobs; so = rhoobs; 
            uo = uobs; vo = vobs;
         end
         [a2,chisq,pres,vres,ppp,vvv] = ...
            fit_gwe_w2p(rpo,po,sigr,sigp,a0,ia,rrfit,1, ...
               trackcom,ho,luo,so,ruo,uo,vo,zobs,0);
         if ~isnan(a2)
            awpmc(kk,ii,:) = a2'; chisqwpmc(kk,ii) = chisq;
            ppfitmc(kk,ii,:) = ppp';
            vgfitmc(kk,ii,:) = vvv';
         end
      end
   end
   save('analyse_gwe_w2p_temp');
 % load('analyse_gwe_w2p_temp');
   if 0
      fig(1); clf;
      subplot(2,1,1); cla reset;
      plot(rrfit,squeeze(ppfitmc(kk,:,:)),'b-'); hold on;
      plot(rpobs,pobs,'ro');
      subplot(2,1,2); cla reset;
      plot(rrfit,squeeze(vgfitmc(kk,:,:)),'b-'); hold on;
      plot(ruobs,vobs,'ro');
   end
end

if 0 % debug stuff
   a0 = awp(kk,:)';
   ia = [ 1 1 1 0 1 0 1 0 ]';   % Don't fit n1, L2 or Tbar
   [a2,covar,chisq] = mrqmin2(ro,po,sigr,sigp,a0,ia,@willoughby2_p_num_fixblend,50,3);
end

 save(savenamemc)
% load(savenamemc)
nr = 5; nc = 6;

fig(7); clf;
for kk = 2 : 25 % 1 : min(nzfit,nr*nc)
   iz = find(zz == zfit(kk));
   use = find(rsel1 < rrel(iz,:) & rrel(iz,:) < rsel2 & ~isnan(zuex(iz,:)) & timeok(iz,:) );
   rpobs = rrelT(use)';   % Radii of p, T, etc
   ruobs = rrel(iz,use)';  % Radii of winds
   pobs = zp(iz,use)';
   uobs = ucrel(iz,use)'; vobs = vcrel(iz,use)'; Tobs = zTv(iz,use)';
   rhoobs = pobs./(287.04*Tobs);
   lobs = lamrel(iz,use)'; hobs = hr(iz,use)';
   zobs = zfit(kk); nobs(kk) = length(use);
   %subplot(nr,nc,kk); cla;
   subplot(nr,nc,kk-1); cla;
   plot(rrfit*1e-3,squeeze(vgfitmc(kk,:,:))','r-'); hold on;
   plot(ruobs*1e-3,vobs,'bo','MarkerSize',4); 
   xlim(0,rsel2*1e-3); 
   ylim(-10,80);
   if (kk == 3), title([event ' Dropsonde Obs vaz and Fitted vgr']); end
   if (kk < (nr-1)*nc); noxlab; else xlabel('Radius (km)'); end;
   if (mod(kk,nc) == 1), ylabel('vaz (m/s)'); end;
   h = reltext(0.95,0.9,sprintf('%.0fm',zfit(kk)));
   set(h,'HorizontalAlignment','right','Fontsize',8);
end

barawpmc = zeros(nzfit,na) + nan;
barvmwpmc = zeros(nzfit,1) + nan;
barvgwpmc = zeros(nzfit,nrrfit) + nan;
barppwpmc = zeros(nzfit,nrrfit) + nan;
sigawpmc = zeros(nzfit,na) + nan;
sigvmwpmc = zeros(nzfit,1) + nan;
sigvgwpmc = zeros(nzfit,nrrfit) + nan;
sigppwpmc = zeros(nzfit,nrrfit) + nan;

ciawpmc = zeros(nzfit,na,2) + nan;
civmwpmc = zeros(nzfit,2) + nan;
civgwpmc = zeros(nzfit,nrrfit,2) + nan;
cippwpmc = zeros(nzfit,nrrfit,2) + nan;

for kk = 10 : nzfit
   use = find(~isnan(chisqwpmc(kk,:)));
   if ~isempty(use)
      barawpmc(kk,:) = mean(squeeze(awpmc(kk,use,:)),1); 
      sigawpmc(kk,:) =  std(squeeze(awpmc(kk,use,:)),1);
      barvmwpmc(kk)  = mean(squeeze(awpmc(kk,use,1) + awpmc(kk,use,3)));
      sigvmwpmc(kk)  =  std(squeeze(awpmc(kk,use,1) + awpmc(kk,use,3)));
      barvgwpmc(kk,:) = mean(squeeze(vgfitmc(kk,use,:)),1); 
      sigvgwpmc(kk,:) =  std(squeeze(vgfitmc(kk,use,:)),1);
      barppwpmc(kk,:) = mean(squeeze(ppfitmc(kk,use,:)),1); 
      sigppwpmc(kk,:) =  std(squeeze(ppfitmc(kk,use,:)),1);

      ciawpmc(kk,:,:)  = myprctile(squeeze(awpmc(kk,use,:)),[5,95])';
      civmwpmc(kk,:,:) = myprctile(squeeze(awpmc(kk,use,1)+awpmc(kk,use,3)),[5,95])';
      civgwpmc(kk,:,:) = myprctile(squeeze(vgfitmc(kk,use,:)),[5,95])';
      cippwpmc(kk,:,:) = myprctile(squeeze(ppfitmc(kk,use,:)),[5,95])';
   end
end

for kk = 1 : nzfit
   ppfit0(kk,:) = willoughby2_p_numerical(rrfit,awp(kk,:)')';
   vgfit0(kk,:) = willoughby2_v(rrfit,awp(kk,:)')';
end

% save(savenamemc)

pscal = [ 1 1e-3 1 1e-3 1e-3 1 1e-2 1 ]';
ptit = { 'vm1', 'L1', 'vm2','L2','rm', 'n1', 'pc', 'Tv' }';
fig(8); clf;
set(gcf,'PaperPosition',[2 2 12 10]);
for ii = 1 : 8
   subplot(2,5,ii); cla; 
   plot(squeeze(awpmc(:,:,ii))*pscal(ii),zfit*1e-3); 
   ylim(0,3); 
   if mod(ii,5) ~= 1, set(gca,'YTick',[]); else ylabel('z (km)'); end
   xlabel(ptit(ii));
end
subplot(2,5,9); cla;
plot(awpmc(:,:,1) + awpmc(:,:,3),zfit/1e3,'b-'); 
ylim(0,3); 
xlabel('vm1 + vm2'); set(gca,'YTick',[]);
subplot(2,5,10); cla;
plot(chisqwpmc,zfit/1e3,'b-'); 
ylim(0,3); 
xlabel('\chi^2 = Error of fit'); set(gca,'YTick',[]);

fig(8); clf;
set(gcf,'PaperPosition',[2 2 12 10]);
subplot(1,2,1); cla reset;
plot(barvmwpmc,zfit/1e3,'b-'); hold on; 
plot(barvmwpmc - 2.0*sigvmwpmc,zfit/1e3,'b--');
plot(barvmwpmc + 2.0*sigvmwpmc,zfit/1e3,'b--');
plot(civmwpmc(:,1),zfit/1e3,'r--');
plot(civmwpmc(:,2),zfit/1e3,'r--');
ylim(0,2.5); 
xlabel('vm'); 
subplot(1,2,2); cla reset;
plot(barawpmc(:,5)*1e-3,zfit/1e3,'b-'); hold on; 
plot((barawpmc(:,5) - 2.0*sigawpmc(:,5))*1e-3,zfit/1e3,'b--');
plot((barawpmc(:,5) + 2.0*sigawpmc(:,5))*1e-3,zfit/1e3,'b--');
plot(ciawpmc(:,5,1)/1e3,zfit/1e3,'r--');
plot(ciawpmc(:,5,2)/1e3,zfit/1e3,'r--');
ylim(0,2.5); 
xlabel('rm'); 

fig(9); clf;
for kk = 1 : min(nzfit, nr*nc)
   iz = find(zz == zfit(kk));
   use = find(rsel1 < rrel(iz,:) & rrel(iz,:) < rsel2 & ~isnan(zuex(iz,:)) & timeok(iz,:) );
   rpobs = rrelT(use)';   % Radii of p, T, etc
   ruobs = rrel(iz,use)';  % Radii of winds
   pobs = zp(iz,use)';
   uobs = ucrel(iz,use)'; vobs = vcrel(iz,use)'; Tobs = zTv(iz,use)';
   rhoobs = pobs./(287.04*Tobs);
   lobs = lamrel(iz,use)'; hobs = hr(iz,use)';
   zobs = zfit(kk); nobs(kk) = length(use);
   subplot(nr,nc,kk); cla;
   plot(rrfit*1e-3,squeeze(ppfitmc(kk,:,:))'*1e-2,'r-'); hold on;
   plot(rpobs*1e-3,pobs*1e-2,'bo','MarkerSize',4); 
   xlim(0,rsel2*1e-3);
   ylim(min(pobs)/1e2 - 10, max(pobs)/1e2 + 30);
   if (kk == 3), title([event ' Dropsonde Obs p and Fitted pgr']); end
   if (kk < (nr-1)*nc); noxlab; else xlabel('Radius (km)'); end;
   if (mod(kk,nc) == 1), ylabel('p (hPa)'); end;
   h = reltext(0.95,0.9,sprintf('%.0fm',zfit(kk)));
   set(h,'HorizontalAlignment','right','Fontsize',8);
end

fig(10); clf;
for kk = 1 : min(nzfit, nr*nc)
   iz = find(zz == zfit(kk));
   use = find(rsel1 < rrel(iz,:) & rrel(iz,:) < rsel2 & ~isnan(zuex(iz,:)) & timeok(iz,:) );
   rpobs = rrelT(use)';   % Radii of p, T, etc
   ruobs = rrel(iz,use)';  % Radii of winds
   pobs = zp(iz,use)';
   uobs = ucrel(iz,use)'; vobs = vcrel(iz,use)'; Tobs = zTv(iz,use)';
   rhoobs = pobs./(287.04*Tobs);
   lobs = lamrel(iz,use)'; hobs = hr(iz,use)';
   zobs = zfit(kk); nobs(kk) = length(use);
   pgm = barppwpmc(kk,:) - 2*sigppwpmc(kk,:);
   pgp = barppwpmc(kk,:) + 2*sigppwpmc(kk,:);
   subplot(nr,nc,kk); cla;
   h = patch([ rrfit' rrfit(nrrfit:-1:1)' ]*1e-3, ...
             [ pgp pgm(nrrfit:-1:1) ]*1e-2, 'y');
   set(h,'EdgeColor','y');
   hold on;
   plot(rrfit*1e-3,ppfit0(kk,:)*1e-2,'r-'); 
   plot(rpobs*1e-3,pobs*1e-2,'bo','MarkerSize',4);
   xlim(0,rsel2*1e-3);
   ylim(min(pobs)/1e2 - 10, max(pobs)/1e2 + 30);
   if (kk == 3), title([event ' Dropsonde Obs p and Fitted p']); end
   if (kk < (nr-1)*nc); noxlab; else xlabel('Radius (km)'); end;
   if (mod(kk,nc) == 1), ylabel('p (hPa)'); end;
   h = reltext(0.95,0.9,sprintf('%.0fm',zfit(kk)));
   set(h,'HorizontalAlignment','right','Fontsize',8);
end


fig(11); clf;
for kk = 1 : min(nzfit, nr*nc)
   iz = find(zz == zfit(kk));
   use = find(rsel1 < rrel(iz,:) & rrel(iz,:) < rsel2 & ~isnan(zuex(iz,:)) & timeok(iz,:) );
   rpobs = rrelT(use)';   % Radii of p, T, etc
   ruobs = rrel(iz,use)';  % Radii of winds
   pobs = zp(iz,use)';
   uobs = ucrel(iz,use)'; vobs = vcrel(iz,use)'; Tobs = zTv(iz,use)';
   rhoobs = pobs./(287.04*Tobs);
   lobs = lamrel(iz,use)'; hobs = hr(iz,use)';
   zobs = zfit(kk); nobs(kk) = length(use);
   vvm = barvgwpmc(kk,:) - 2*sigvgwpmc(kk,:);
   vvp = barvgwpmc(kk,:) + 2*sigvgwpmc(kk,:);
   subplot(nr,nc,kk); cla;
   h = patch([ rrfit' rrfit(nrrfit:-1:1)' ]*1e-3, ...
             [ vvp vvm(nrrfit:-1:1) ], 'y');
   set(h,'EdgeColor','y');
   hold on;
   plot(rrfit*1e-3,vgfit0(kk,:),'r-'); 
   plot(ruobs*1e-3,vobs,'bo','MarkerSize',4);
   xlim(0,rsel2*1e-3);
   ylim(-10,80);
   if (kk == 3), title([event ' Dropsonde Obs v_{az} and Fitted v_{gr}']); end
   if (kk < (nr-1)*nc); noxlab; else xlabel('Radius (km)'); end;
   if (mod(kk,nc) == 1), ylabel('v_c (m/s)'); end;
   h = reltext(0.95,0.9,sprintf('%.0fm',zfit(kk)));
   set(h,'HorizontalAlignment','right','Fontsize',8);
end


fig(12); clf;
kk = 05;
   iz = find(zz == zfit(kk));
   use = find(rsel1 < rrel(iz,:) & rrel(iz,:) < rsel2 & ~isnan(zuex(iz,:)) & timeok(iz,:) );
   rpobs = rrelT(use)';   % Radii of p, T, etc
   ruobs = rrel(iz,use)';  % Radii of winds
   pobs = zp(iz,use)';
   uobs = ucrel(iz,use)'; vobs = vcrel(iz,use)'; Tobs = zTv(iz,use)';
   rhoobs = pobs./(287.04*Tobs);
   lobs = lamrel(iz,use)'; hobs = hr(iz,use)';
   zobs = zfit(kk); nobs(kk) = length(use);
   vvm = barvgwpmc(kk,:) - 2*sigvgwpmc(kk,:);
   vvp = barvgwpmc(kk,:) + 2*sigvgwpmc(kk,:);
   h = patch([ rrfit' rrfit(nrrfit:-1:1)' ]*1e-3, ...
             [ vvp vvm(nrrfit:-1:1) ], 'y');
   set(h,'EdgeColor','y');
   hold on;
   plot(rrfit*1e-3,vgfit0(kk,:),'r-');
   plot(ruobs*1e-3,vobs,'bo','MarkerSize',4);
   xlim(0,rsel2*1e-3); yrange(100,0,0);
   title([event ' Dropsonde Obs v_{az} and Fitted v_{gr}']); 
   xlabel('Radius (km)'); ylabel('v_c (m/s)'); 
   h = reltext(0.95,0.9,sprintf('%.0fm',zfit(kk)));
   set(h,'HorizontalAlignment','right','Fontsize',8);


