if isunix
    addpath('~hurricanes/tc_cases/matlab');
else
    addpath('c:/Dokumente und Einstellungen/Hurricanes/matlab');
end

format short g
clear
clear global
global f0

load('matlab/Danielle_19980830HI_dropsonde_10_hydroadj');
f0 = cor(tclat0);

hr = 24*(ztime - time0);
meantime = nanmean(ztime);
meanhr = 24*(meantime - time0);
sec = 3600*hr;
zTv = zT.*(1 + 0.608*zq);

% flightlevel p-track: 0 for all 
tracktype = 0;

if tracktype == 0  % Relative to flight-level track
   savename = 'matlab/results_gwe_w2v_fl';
   load('matlab/results_flightlevel_980830I','ah');
   xt = ah(6) + zeros(size(zx,1), 1); yt = ah(7) + zeros(size(zx,1), 1);
   ut = ah(8) + zeros(size(zx,1), 1); vt = ah(9) + zeros(size(zx,1), 1);
   timeok = ones(size(hr));
   trackcom = 'aircraft-p track';
   nzfit = 31;
   Lb = 10e3; L2 = 500e3;
end

% Convert to storm-relative coordinates
oo = ones(1, size(zx,2));
xrel = zx - xt*oo - (ut*oo).*sec;
yrel = zy - yt*oo - (vt*oo).*sec;
rrel = hypot(xrel,yrel);
lamrel = mod(atan2(yrel,xrel)*180/pi, 360);  % Anticlockwise from +x axis
xrelT = zxT - xt(1) - ut(1)*meanhr*3600;
yrelT = zyT - yt(1) - vt(1)*meanhr*3600;
rrelT = hypot(xrelT,yrelT);
lamrelT = mod(atan2(yrelT,xrelT)*180/pi, 360);  % Anticlockwise from +x axis
uxrel = zuex - ut*oo;   % Storm-relative cartesian winds.
vxrel = zvex - vt*oo;
ucrel = ( uxrel.*xrel + vxrel.*yrel ) ./ rrel;  % Storm-relative cylindrical winds
vcrel = ( vxrel.*xrel - uxrel.*yrel ) ./ rrel;
clear oo

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Fit Willoughby parametric wind profiles at each 100 m level %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
zfit = 100*[0 : nzfit-1]';
rsel1 = 0e3; rsel2 = 200e3;
rrfit = [max(1e3,rsel1):1e3:rsel2]';
nrrfit = length(rrfit); drrfit = rrfit(2) - rrfit(1);

pgfit = zeros(nzfit,nrrfit) + nan;
vvfit = zeros(nzfit,nrrfit) + nan;
chisqwv = zeros(nzfit,1) + nan;
nobs = zeros(nzfit,1) + nan;
na = 9;
awv = zeros(nzfit,na) + nan;
ia1 = [ 1 1 1 0 1 1 0 0 0 ]';
ia2 = [ 0 0 0 0 1 1 0 0 0 ]';

global w2v_rmhat w2v_rmscal w2v_L1hat w2v_L1scal w2v_L2hat w2v_L2scal
w2v_rmhat =  34e3; w2v_rmscal = 0.1;
w2v_L1hat =  130e3; w2v_L1scal = 0.5;
w2v_L2hat =    L2; w2v_L2scal = 0.0;
doplot = 1;

lf = [0:10:360]'; Xf = [ ones(size(lf)) cos(lf*pi/180) sin(lf*pi/180) ];

for kk = 2 : nzfit
   disp(sprintf('kk = %d', kk));
   iz = find( zz == zfit(kk) );
   use = find(rsel1 < rrel(iz,:) & rrel(iz,:) < rsel2 & ~isnan(zuex(iz,:)) & timeok(iz,:));
   ruobs = rrel(iz,use)'; rTobs = rrelT(use);
   luobs = lamrel(iz,use)'; lTobs = lamrelT(use)';
   pobs = zp(iz,use)'; nobs(kk) = length(use);
   uobs = ucrel(iz,use)'; vobs = vcrel(iz,use)'; Tobs = zTv(iz,use)';
   hobs = hr(iz,use)';
   sigv = 5*ones(nobs(kk),1);
   pc = mean(pobs(find(rTobs < 10e3)));
 
%   r1 = [ruobs ; -999]; v1 = [vobs; 0]; sig1 = [sigv; 5];
   r1 = [ruobs]; v1 = [vobs]; sig1 = [sigv];
   a0 = [ 10, 35e3, 25, L2, 30e3, 1.0, pc, nanmean(Tobs) Lb ]'; ia = ia1;
   [a,cov,chisqwv(kk)] = mrqmin(r1, v1, sig1, a0, ia, @willoughby2_v, 100, 10);
 %  if a(3) < 0  % Refit with only one exponential term
 %    a0 = a; a0(3) = 0; ia = ia2;
 %    [a,cov,chisqwv(kk)] = mrqmin(r1, v1, sig1, a0, ia, @willoughby2_v, 100, 10);
 % end
   awv(kk,:) = a';
   nf = nobs(kk) - sum(ia);
   
   pgfit(kk,:) = willoughby2_p_numerical(rrfit,awv(kk,:)')';
   pres        = willoughby2_p_numerical(rTobs, awv(kk,:)') - pobs;
   vvfit(kk,:) = willoughby2_v(rrfit,awv(kk,:)')';
   vres        = willoughby2_v(ruobs, awv(kk,:)') - vobs;

   if doplot
      fig(1); clf; set(gcf,'PaperPosition',[1 5 20 20]);
      subplot(5,2,1); cla reset;
      plot(ruobs/1e3,vobs,'o','MarkerSize',5); hold on;
      plot(rrfit/1e3,vvfit(kk,:),'r-','LineWidth',2);
      xlabel('r'); ylabel('v'); yrange(100,0,0);
      title(sprintf('z=%.0f, \\chi^2/n_f=%.3f, %s',zfit(kk),chisqwv(kk)/nf,trackcom));
      subplot(5,2,2); cla reset;
      plot(rTobs/1e3,pobs/100,'o','MarkerSize',5); hold on;
      plot(rrfit/1e3,pgfit(kk,:)/100,'r-','LineWidth',2);
      xlabel('r'); ylabel('p'); yrange(80,0,0);
      title(sprintf('a=[%.1f %.1f %.1f %.1f %.1f %.2f %.1f]',...
         a(1:7)./[1 1e3 1 1e3 1e3 1 1e2]'));
      subplot(5,2,3); cla reset;
      plot(ruobs/1e3,vres,'o','MarkerSize',5); hold on; hline(0);
      xlabel('r'); ylabel('v res'); 
      subplot(5,2,4); cla reset;
      plot(rTobs/1e3,pres/100,'o','MarkerSize',5); hold on; hline(0);
      xlabel('r'); ylabel('p res'); 
      subplot(5,2,5); cla reset;
      plot(hobs,vres,'o','MarkerSize',5); hold on; hline(0);
      xlabel('hr'); ylabel('v res');
      subplot(5,2,6); cla reset;
      plot(hobs,pres/100,'o','MarkerSize',5); hold on; hline(0);
      xlabel('hr'); ylabel('p res');
      subplot(5,2,7); cla reset;
      X = [ ones(size(luobs)) cos(luobs*pi/180) sin(luobs*pi/180) ];
      b = regress(vres,X);
      plot(luobs,vres,'o','MarkerSize',5); hold on; hline(0); xdegrees;
      plot(lf, Xf*b, 'r-');
      xlabel('Azimuth'); ylabel('v res');
      subplot(5,2,8); cla reset;
      X = [ ones(size(lTobs)) cos(lTobs*pi/180) sin(lTobs*pi/180) ];
      b = regress(pres,X);
      plot(lTobs,pres/100,'o','MarkerSize',5); hold on; hline(0); xdegrees;
      plot(lf, Xf*b*0.01, 'r-');
      xlabel('Azimuth'); ylabel('p res');
      subplot(5,2,9); cla reset;
      plot(uobs,vres,'o','MarkerSize',5); hold on; xrange(60,0,0); hline(0); 
      xlabel('u obs'); ylabel('v res');
      subplot(5,2,10); cla reset;
      plot(uobs,pres/100,'o','MarkerSize',5); hold on; xrange(60,0,0); hline(0);
      xlabel('u obs'); ylabel('p res');
      myeps(gcf, sprintf('fit_gwe_w2v_%04d',zfit(kk)), [10 12]);
   end
end

clear global w2v_rmhat w2v_rmscal w2v_L1hat w2v_L1scal w2v_L2hat w2v_L2scal

fig(1); clf;
for kk = 2 : min(nzfit,31)
   iz = find( zz == zfit(kk) );
   use = find(rsel1 < rrel(iz,:) & rrel(iz,:) < rsel2 & ~isnan(zuex(iz,:)) & timeok(iz,:));
   ruobs = rrel(iz,use)'; rTobs = rrelT(use);
   luobs = lamrel(iz,use)'; lTobs = lamrelT(use)';
   pobs = zp(iz,use)'; nobs(kk) = length(use);
   uobs = ucrel(iz,use)'; vobs = vcrel(iz,use)'; Tobs = zTv(iz,use)';
   hobs = hr(iz,use)';
   subplot(6,5,kk-1); cla;
   if 1
      plot(ruobs*1e-3,vobs,'bo','MarkerSize',4); hold on;
      plot(rrfit*1e-3,vvfit(kk,:),'r-');
      ylim(-10,80);
   else
      vres = vobs - willoughby2_v(ruobs,awv(kk,:)');
      plot(ruobs*1e-3,vres,'bo','MarkerSize',4); hold on;
      hline(0,'r-');
      ylim(-10,10);
   end
   xlim(0,rsel2*1e-3); 
   if (kk == 3), title([event ' Dropsonde vaz: Obs and Fitted']); end
   if (kk < 24); noxlab; else xlabel('Radius (km)'); end;
   if (mod(kk,5) == 1), ylabel('vaz (m/s)'); end;
   h = reltext(0.95,0.9,sprintf('%.0fm',zfit(kk)));
   set(h,'HorizontalAlignment','right','Fontsize',8);
end

pscal = [ 1 1e-3 1 1e-3 1e-3 1 1e-2 1 ]';
ptit = { 'vm1', 'L1', 'vm2','L2','rm', 'n1', 'pc', 'Tv' }';
fig(2); clf;
set(gcf,'PaperPosition',[2 2 12 10]);
for ii = 1 : 8
   subplot(2,5,ii); cla; 
   plot(awv(:,ii)*pscal(ii),zfit*1e-3); hold on;
   ylim(0,3); 
   if mod(ii,5) ~= 1, set(gca,'YTickLabel',[]); else ylabel('z (km)'); end
   xlabel(ptit(ii));
end
subplot(2,5,9); cla;
plot(awv(:,1) + awv(:,3),zfit/1e3,'b-'); 
xlabel('vm1 + vm2'); set(gca,'YTick',[]);
subplot(2,5,10); cla;
plot(chisqwv,zfit/1e3,'b-'); 
xlabel('\chi^2 = Error of fit'); set(gca,'YTick',[]);

fig(3); clf;
for kk = 2 : min(nzfit,31)
   iz = find( zz == zfit(kk) );
   use = find(rsel1 < rrel(iz,:) & rrel(iz,:) < rsel2 & ~isnan(zuex(iz,:)) & timeok(iz,:));
   ruobs = rrel(iz,use)'; rTobs = rrelT(use);
   luobs = lamrel(iz,use)'; lTobs = lamrelT(use)';
   pobs = zp(iz,use)'; nobs(kk) = length(use);
   uobs = ucrel(iz,use)'; vobs = vcrel(iz,use)'; Tobs = zTv(iz,use)';
   hobs = hr(iz,use)';
   subplot(6,5,kk-1); cla;
   if 1
      plot(rTobs*1e-3,pobs/1e2,'bo','MarkerSize',4); hold on;
      plot(rrfit*1e-3,pgfit(kk,:)/1e2,'r-');
      yrange(90,0,0);
   else
      pres = pobs - willoughby2_p_numerical(rTobs,awv(kk,:)');
      plot(rTobs*1e-3,pres/1e2,'bo','MarkerSize',4); hold on;
      hline(0,'r'); ylim(-20,20);
   end
   xlim(0,rsel2*1e-3); 
   if (kk == 3), title([event ' Dropsonde Obs p and Fitted pgr']); end
   if (kk < 26); noxlab; else xlabel('Radius (km)'); end;
   if (mod(kk,5) == 1), ylabel('p (hPa)'); end;
   h = reltext(0.95,0.9,sprintf('%.0fm',zfit(kk)));
   set(h,'HorizontalAlignment','right','Fontsize',8);
end

% Check residuals against azimuth
b = zeros(nzfit,3);
rmn = 15e3; rmx = 40e3;
% rmn = 50e3; rmx = 100e3;
fig(4); clf;
for kk = 2 : min(nzfit,31)
   iz = find( zz == zfit(kk) );
   use = find(rsel1 < rrel(iz,:) & rrel(iz,:) < rsel2 & ~isnan(zuex(iz,:)) & timeok(iz,:));
   ruobs = rrel(iz,use)'; rTobs = rrelT(use);
   luobs = lamrel(iz,use)'; lTobs = lamrelT(use)';
   pobs = zp(iz,use)'; nobs(kk) = length(use);
   uobs = ucrel(iz,use)'; vobs = vcrel(iz,use)'; Tobs = zTv(iz,use)';
   hobs = hr(iz,use)';
   vres = vobs - willoughby2_v(ruobs,awv(kk,:)');
   X = [ ones(size(luobs)) cos(luobs*pi/180) sin(luobs*pi/180) ];
   b(kk,:) = regress(vres,X)';
   
   subplot(6,5,kk-1); cla;
   plot(luobs,vres,'bo','MarkerSize',4); hold on;
   plot(lf,Xf*b(kk,:)','r-','MarkerSize',4); 
   xlim(0,360); xtick(0:90:360); ylim(-10,10);
   if (kk == 4), title([event ' Dropsonde vaz: Residuals']); end
   if (kk < 25); noxlab; else xlabel('Azimuth (^o)'); end;
   if (mod(kk,5) == 2), ylabel('vaz (m/s)'); end;
   h = reltext(0.95,0.9,sprintf('%.0fm',zfit(kk)));
   set(h,'HorizontalAlignment','right','Fontsize',8);
end

fig(5); clf;
set(gcf,'PaperPosition',[2 2 15 10]);
subplot(1,3,1); plot(b(:,1),zfit);
subplot(1,3,2); plot(hypot(b(:,2),b(:,3)),zfit);
subplot(1,3,3); plot(mod(atan2(b(:,3),b(:,2))*180/pi,360),zfit); xdegrees;

% save(savename)
% load(savename)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Monte-Carlo Willoughby v fits %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

savenamemc = [ savename 'mc' ];
nmc = 200;
na = 9; 
ia1 = [ 1 1 1 0 1 1 0 0 0 ]';
ia2 = [ 1 1 0 0 1 1 0 0 0 ]';
pgfit = zeros(nzfit,nmc,nrrfit) + nan;
vvfit = zeros(nzfit,nmc,nrrfit) + nan;
awvmc = zeros(nzfit,nmc,na) + nan;
chisqwvmc = zeros(nzfit,nmc) + nan;
nobs = zeros(nzfit,1) + nan;
sig_obs = 5;
sig_pert = 4;

global w2v_rmhat w2v_rmscal w2v_L1hat w2v_L1scal w2v_L2hat w2v_L2scal

for kk = 2 : nzfit
   w2v_rmhat =  22e3; w2v_rmscal = 0.1;
   w2v_L1hat =  50e3; w2v_L1scal = 0.5;
   w2v_L2hat =    L2; w2v_L2scal = 1.0;
   disp(sprintf('kk = %d', kk));
   iz = find( zz == zfit(kk) );
   use = find(rsel1 < rrel(iz,:) & rrel(iz,:) < rsel2 & ~isnan(zuex(iz,:)) & timeok(iz,:));
   ruobs = rrel(iz,use)'; rTobs = rrelT(use);
   luobs = lamrel(iz,use)'; lTobs = lamrelT(use)';
   pobs = zp(iz,use)'; nobs(kk) = length(use);
   uobs = ucrel(iz,use)'; vobs = vcrel(iz,use)'; Tobs = zTv(iz,use)';
   hobs = hr(iz,use)';
   sigv = 5*ones(nobs(kk),1);
   pc = mean(pobs(find(rTobs < 10e3)));
   sigv = sig_obs*ones(nobs(kk),1);
   for ii = 1 : nmc
      for iter = 1 : 20  % Necessary for occasional solution failures
         vo = vobs + sig_pert.*randn(nobs(kk),1);
         r1 = [ ruobs ; -999.0 ]; vo1 = [ vo ; 0 ]; sig1 = [ sigv ; 5 ];
         a0 = awv(kk,:)'; 
         if a0(3) == 0, a0(3) = 25; a0(1) = a0(1) - a0(3); end
         [a,cov,chisqwvmc(kk,ii)] = mrqmin(r1, vo1, sig1, a0, ia1, @willoughby2_v, 100, 10);
         if ~any(isnan(a)) 
            if a(3) >= 0, 
               break; 
            else  % Refit with only one exponential term
               a0 = a; a0(1) = a0(1) + a0(3); a0(3) = 0; a0(4) = L2; w2v_L2scal = 0;
               [a,cov,chisqwv(kk)] = mrqmin(r1, vo1, sig1, a0, ia2, @willoughby2_v, 100, 10);
               if ~any(isnan(a)), break; end
            end
         end
      end
      awvmc(kk,ii,:) = a';
      
      pgfit(kk,ii,:) = willoughby2_p_numerical(rrfit,a)';
      vvfit(kk,ii,:) = willoughby2_v(rrfit,a)';
   end
end

clear global w2v_rmhat w2v_rmscal w2v_L1hat w2v_L1scal w2v_L2hat w2v_L2scal

% save(savenamemc)
% load(savenamemc)

nr = 6; nc = 5;

fig(14); clf;
for kk = 2 : 25 % 2:min(nzfit,31)
   iz = find( zz == zfit(kk) );
   use = find(rsel1 < rrel(iz,:) & rrel(iz,:) < rsel2 & ~isnan(zuex(iz,:)) & timeok(iz,:));
   ruobs = rrel(iz,use)'; rTobs = rrelT(use);
   luobs = lamrel(iz,use)'; lTobs = lamrelT(use)';
   pobs = zp(iz,use)'; nobs(kk) = length(use);
   uobs = ucrel(iz,use)'; vobs = vcrel(iz,use)'; Tobs = zTv(iz,use)';
   hobs = hr(iz,use)';
   %subplot(nr,nc,kk); cla;
   subplot(nr,nc,kk-1); cla;
   %subplot(6,5,kk-1); cla;
   plot(rrfit*1e-3,squeeze(vvfit(kk,:,:))','r-'); hold on;
   plot(ruobs*1e-3,vobs,'bo','MarkerSize',4); 
   xlim(0,rsel2*1e-3); 
   ylim(-10,80);
   if (kk == 3), title([event ' Dropsonde vaz: Obs and Fitted']); end
   if (kk < 24); noxlab; else xlabel('Radius (km)'); end;
   if (mod(kk,5) == 1), ylabel('vaz (m/s)'); end;
   h = reltext(0.95,0.9,sprintf('%.0fm',zfit(kk)));
   set(h,'HorizontalAlignment','right','Fontsize',8);
end

barawvmc = squeeze(mean(awvmc,2)); sigawvmc = squeeze(std(awvmc,0,2));
barvvwvmc = squeeze(mean(vvfit,2)); sigvvwvmc = squeeze(std(vvfit,0,2));
barpgwvmc = squeeze(mean(pgfit,2)); sigpgwvmc = squeeze(std(pgfit,0,2));

ciawvmc = zeros(nzfit,na,2) + nan;
civmwvmc = zeros(nzfit,2) + nan;
civvwvmc = zeros(nzfit,nrrfit,2) + nan;
cipgwvmc = zeros(nzfit,nrrfit,2) + nan;
for kk = 2 : nzfit
   ciawvmc(kk,:,:)  = myprctile(squeeze(awvmc(kk,:,:)),[5,95])';
   civmwvmc(kk,:,:) = myprctile(squeeze(awvmc(kk,:,1)+awvmc(kk,:,3)),[5,95])';
   civvwvmc(kk,:,:) = myprctile(squeeze(vvfit(kk,:,:)),[5,95])';
   cipgwvmc(kk,:,:) = myprctile(squeeze(pgfit(kk,:,:)),[5,95])';
end

for kk = 2 : nzfit
   pgfit0(kk,:) = willoughby2_p_numerical(rrfit,awv(kk,:)')';
   vvfit0(kk,:) = willoughby2_v(rrfit,awv(kk,:)')';
end

% save(savenamemc)

pscal = [ 1 1e-3 1 1e-3 1e-3 1 1e-2 1 ]';
ptit = { 'vm1', 'L1', 'vm2','L2','rm', 'n1', 'pc', 'Tv' }';
fig(15); clf;
set(gcf,'PaperPosition',[2 2 12 10]);
for ii = 1 : 8
   subplot(2,5,ii); cla; 
   plot(squeeze(awvmc(:,:,ii))*pscal(ii),zfit*1e-3); hold on;
   plot(mean(squeeze(awvmc(:,:,ii)),2)*pscal(ii),zfit*1e-3,'k-','LineWidth',2); 
   ylim(0,3); 
   if mod(ii,5) ~= 1, set(gca,'YTick',[]); else ylabel('z (km)'); end
   xlabel(ptit(ii));
end
subplot(2,5,9); cla;
plot(awvmc(:,:,1) + awvmc(:,:,3),zfit/1e3,'b-'); hold on; 
plot(mean(squeeze(awvmc(:,:,1)+awvmc(:,:,3)),2)*pscal(ii),zfit*1e-3,'k-','LineWidth',2); 
xlabel('vm1 + vm2'); set(gca,'YTick',[]);
subplot(2,5,10); cla;
plot(chisqwvmc,zfit/1e3,'b-'); hold on;
plot(mean(chisqwvmc,2),zfit/1e3,'k-','LineWidth',2); 
xlabel('\chi^2 = Error of fit'); set(gca,'YTick',[]);

fig(16); clf;
for kk = 2 : min(nzfit,31)
   iz = find( zz == zfit(kk) );
   use = find(rsel1 < rrel(iz,:) & rrel(iz,:) < rsel2 & ~isnan(zuex(iz,:)) & timeok(iz,:));
   ruobs = rrel(iz,use)'; rTobs = rrelT(use);
   luobs = lamrel(iz,use)'; lTobs = lamrelT(use)';
   pobs = zp(iz,use)'; nobs(kk) = length(use);
   uobs = ucrel(iz,use)'; vobs = vcrel(iz,use)'; Tobs = zTv(iz,use)';
   hobs = hr(iz,use)';
   subplot(6,5,kk-1); cla;
   plot(rrfit*1e-3,squeeze(pgfit(kk,:,:))'*1e-2,'r-'); hold on;
   plot(rTobs*1e-3,pobs*1e-2,'bo','MarkerSize',4); 
   xlim(0,rsel2*1e-3); yrange(90,0,0);
   if (kk == 3), title([event ' Dropsonde Obs p and Fitted pgr']); end
   if (kk < 24); noxlab; else xlabel('Radius (km)'); end;
   if (mod(kk,5) == 1), ylabel('p (hPa)'); end;
   h = reltext(0.95,0.9,sprintf('%.0fm',zfit(kk)));
   set(h,'HorizontalAlignment','right','Fontsize',8);
end

fig(17); clf;
for kk = 1 : min(nzfit,30)
   iz = find( zz == zfit(kk) );
   use = find(rsel1 < rrel(iz,:) & rrel(iz,:) < rsel2 & ~isnan(zuex(iz,:)) & timeok(iz,:));   
   ruobs = rrel(iz,use)'; rTobs = rrelT(use);
   luobs = lamrel(iz,use)'; lTobs = lamrelT(use)';
   pobs = zp(iz,use)'; nobs(kk) = length(use);
   uobs = ucrel(iz,use)'; vobs = vcrel(iz,use)'; Tobs = zTv(iz,use)';
   hobs = hr(iz,use)';
%  pgm = barpgwvmc(kk,:) - 2*sigpgwvmc(kk,:);
%  pgp = barpgwvmc(kk,:) + 2*sigpgwvmc(kk,:);
   pgm = cipgwvmc(kk,:,1);
   pgp = cipgwvmc(kk,:,2);
   subplot(6,5,kk); cla;
   h = patch([ rrfit' rrfit(nrrfit:-1:1)' ]*1e-3, ...
             [ pgp pgm(nrrfit:-1:1) ]*1e-2, 'y');
   set(h,'EdgeColor','y');
   hold on;
   plot(rrfit*1e-3,pgfit0(kk,:)*1e-2,'r-'); 
   plot(rTobs*1e-3,pobs*1e-2,'bo','MarkerSize',4);
   xlim(0,rsel2*1e-3);
   ylim(min(pobs)/1e2 - 10, max(pobs)/1e2 + 30);
   if (kk == 3), title([event ' Dropsonde Obs p and Fitted pgr']); end
   if (kk < 24); noxlab; else xlabel('Radius (km)'); end;
   if (mod(kk,5) == 1), ylabel('p (hPa)'); end;
   h = reltext(0.95,0.9,sprintf('%.0fm',zfit(kk)));
   set(h,'HorizontalAlignment','right','Fontsize',8);
end

fig(18); clf;
for kk = 1 : min(nzfit,30)
   iz = find( zz == zfit(kk) );
   use = find(rsel1 < rrel(iz,:) & rrel(iz,:) < rsel2 & ~isnan(zuex(iz,:)) & timeok(iz,:));
   ruobs = rrel(iz,use)'; rTobs = rrelT(use);
   luobs = lamrel(iz,use)'; lTobs = lamrelT(use)';
   pobs = zp(iz,use)'; nobs(kk) = length(use);
   uobs = ucrel(iz,use)'; vobs = vcrel(iz,use)'; Tobs = zTv(iz,use)';
   hobs = hr(iz,use)';
%  vvm = barvvwvmc(kk,:) - 2*sigvvwvmc(kk,:);
%  vvp = barvvwvmc(kk,:) + 2*sigvvwvmc(kk,:);
   vvm = civvwvmc(kk,:,1);
   vvp = civvwvmc(kk,:,2);
   subplot(6,5,kk); cla;
   h = patch([ rrfit' rrfit(nrrfit:-1:1)' ]*1e-3, ...
             [ vvp vvm(nrrfit:-1:1) ], 'y');
   set(h,'EdgeColor','y');
   hold on;
   plot(rrfit*1e-3,vvfit0(kk,:),'r-'); 
   plot(ruobs*1e-3,vobs,'bo','MarkerSize',4);
   xlim(0,rsel2*1e-3);
   ylim(-10,80);
   if (kk == 3), title([event ' Dropsonde Obs v_c and Fitted v']); end
   if (kk < 24); noxlab; else xlabel('Radius (km)'); end;
   if (mod(kk,5) == 1), ylabel('v_c (m/s)'); end;
   h = reltext(0.95,0.9,sprintf('%.0fm',zfit(kk)));
   set(h,'HorizontalAlignment','right','Fontsize',8);
end

load('matlab/results_gwe_w2v_flmc','awv','ciawvmc','civmwvmc');
load('matlab/results_gwe_w2p_hy_fl_pert','awp','ciawpmc','civmwpmc');
fig(19); clf;
subplot(1,2,1); cla reset;
plot(awv(:,1) + awv(:,3), zfit/1e3, 'b-'); hold on;
plot(civmwvmc, zfit/1e3, 'b--');
plot(awp(:,1) + awp(:,3), [0;zfit]/1e3, 'r-'); 
plot(civmwpmc, [0;zfit]/1e3, 'r--');
xlim(55,85); xlabel('v_{max} (m/s)'); ylabel('z (km)');
subplot(1,2,2); cla reset;
plot(awv(:,5)/1e3, zfit/1e3, 'b-'); hold on;
plot(squeeze(ciawvmc(:,5,:))/1e3, zfit/1e3, 'b--');
plot(awp(:,5)/1e3, [0;zfit]/1e3, 'r-'); 
plot(squeeze(ciawpmc(:,5,:))/1e3, [0;zfit]/1e3, 'r--');
xlim(15,35); xlabel('r_{max} (km)');


